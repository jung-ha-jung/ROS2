/* Author: Mincheul Kang */

#include <boost/chrono.hpp>
#include <boost/foreach.hpp>
#include <ompl/base/SpaceInformation.h>

#include <hyundai_planner/sbmp/ConstrainedMotionValidator.h>

ConstrainedMotionValidator::ConstrainedMotionValidator(const ompl::base::SpaceInformationPtr &si,
                                                       KinematicsSolverPtr &ksolver,
                                                       const std::vector<bool> &is_continuous,
                                                       const std::vector<std::pair<double, double> > &constraints,
                                                       const std::vector<double> &start_state):
        si_(si),
        ompl::base::MotionValidator(si),
        state_space_(si->getStateSpace().get()),
        ksolver_(ksolver),
        is_continuous_(is_continuous),
        constraints_(constraints){
    ompl::base::State *state = si_->allocState();
    auto *rstate = static_cast<ompl::base::CompoundState *>(state);
    for(uint k = 0; k < is_continuous_.size(); k++){
        if(is_continuous_[k])
            rstate->as<ompl::base::SO2StateSpace::StateType>(k)->value = start_state[k];
        else
            rstate->as<ompl::base::RealVectorStateSpace::StateType>(k)->values[0] = start_state[k];
    }
    updateConstraints(state);
    si_->freeState(state);
}

std::vector<double> ConstrainedMotionValidator::getEEPose(ompl::base::State *state) const{
    std::vector<double> eePose;

    KDL::JntArray q(si_->getStateDimension());
    KDL::Frame p;

    auto *rstate = static_cast<ompl::base::CompoundState *>(state);
    for(uint k = 0; k < is_continuous_.size(); k++){
        if(is_continuous_[k])
            q(k) = rstate->as<ompl::base::SO2StateSpace::StateType>(k)->value;
        else
            q(k) = rstate->as<ompl::base::RealVectorStateSpace::StateType>(k)->values[0];
    }
    ksolver_->fkSolver(q, p);

    KDL::Frame targetFrame = baseFrame_.Inverse() * p;

    for(int i = 0; i < 9; i++){
        if(i == 1 || i == 2 || i == 4 || i == 5)
            continue;
        else if(std::abs(targetFrame.M.data[i]) < 1e-5){
            targetFrame.M.data[i] = 0.0;
        }
        else if(targetFrame.M.data[i] > 1){
            targetFrame.M.data[i] = 1;
        }
        else if(targetFrame.M.data[i] < -1){
            targetFrame.M.data[i] = -1;
        }
    }

    eePose.push_back(p.p.data[0]);
    eePose.push_back(p.p.data[1]);
    eePose.push_back(p.p.data[2]);
    eePose.push_back(atan2(targetFrame.M.data[7], targetFrame.M.data[8]));
    eePose.push_back(-asin(targetFrame.M.data[6]));
    eePose.push_back(atan2(targetFrame.M.data[3], targetFrame.M.data[0]) );

    return eePose;
}

void ConstrainedMotionValidator::updateConstraints(ompl::base::State *state){
    std::vector<double> eePose = getEEPose(state);
    update_constraints_.clear();
    for(auto i = 0; i < constraints_.size(); i++){
        std::pair<double, double> c = constraints_[i];
        if(c.first == 0 && c.second == 0){
            update_constraints_.push_back(c);
            continue;
        }
        double lower, upper;
        lower = c.first + eePose[i];
        if(lower < -M_PI)
            lower += 2*M_PI;
        upper = c.second + eePose[i];
        if(upper > M_PI)
            upper -= 2*M_PI;
        update_constraints_.push_back(std::make_pair(lower, upper));
    }
}

bool ConstrainedMotionValidator::satisfyConstraints(ompl::base::State *state) const{
    std::vector<double> eePose = getEEPose(state);
    for(auto i = 0; i < update_constraints_.size(); i++){
        std::pair<double, double> c = update_constraints_[i];
        if(c.first == 0 && c.second == 0){
            continue;
        }
        double v = eePose[i];
        if(c.first < c.second){
            if(c.first > v || c.second < v){
                return false;
            }
        }
        else{
            if(c.first < v || c.second > v){
                return false;
            }
        }
    }
    return true;
}

bool ConstrainedMotionValidator::checkMotion(const ompl::base::State *s1, const ompl::base::State *s2) const{
    /* Assume motion starts/ends in a valid configuration so v1/v2 are valid */
    bool result = true;
    int nd = si_->getStateSpace()->validSegmentCount(s1, s2);

    if (nd > 1) {
        /* Temporary storage for the checked state */
        ompl::base::State *test = si_->allocState();

        std::queue<std::pair<unsigned int, unsigned int> > q;
        q.push(std::make_pair(1, nd - 1));

        while (!q.empty()) {
            auto range = q.front();
            unsigned int mid;

            mid = (range.first + range.second) / 2;
            si_->getStateSpace()->interpolate(s1, s2, (double)mid / (double)nd, test);

            if (mid % 5 == 0){
                if (!satisfyConstraints(test)){
                    result = false;
                    break;
                }
            }
            if (!si_->isValid(test)) {
                result = false;
                break;
            }

            q.pop();
            if (range.first < mid)
                q.push(std::make_pair(range.first, mid - 1));
            if (mid < range.second) {
                q.push(std::make_pair(mid + 1, range.second));
            } // if mid == first, no more recursion.
        }
    }

    return result;
}

bool ConstrainedMotionValidator::checkMotion(const ompl::base::State *s1, const ompl::base::State *s2, std::pair<ompl::base::State *, double> &lastValid) const {
    return checkMotion(s1, s2);
}