/* Author: Mincheul Kang */

#include <hyundai_planner/sbmp/DynamicLazyPRMstar.h>
#include "ompl/base/objectives/PathLengthOptimizationObjective.h"
#include "ompl/base/goals/GoalSampleableRegion.h"
#include "ompl/util/GeometricEquations.h"
#include "ompl/geometric/planners/prm/ConnectionStrategy.h"
#include "ompl/tools/config/SelfConfig.h"

#include <boost/graph/astar_search.hpp>
#include <boost/graph/lookup_edge.hpp>
#include <boost/foreach.hpp>
#include <fstream>
#include <queue>
#include <stack>
#include <utility>

#define foreach BOOST_FOREACH

namespace ompl {
    namespace magic {
/** \brief The number of nearest neighbors to consider by
      default in the construction of the PRM roadmap */
        static const unsigned int DEFAULT_NEAREST_NEIGHBORS_LAZY = 5;

/** \brief When optimizing solutions with lazy planners, this is the minimum
      number of path segments to add before attempting a new optimized solution
          extraction */
        static const unsigned int MIN_ADDED_SEGMENTS_FOR_LAZY_OPTIMIZATION = 5;
    }
}

ompl::geometric::DynamicLazyPRMstar::DynamicLazyPRMstar(const base::SpaceInformationPtr &si,
                                                        bool starStrategy) :
        base::Planner(si, "DynamicLazyPRMstar"),
        starStrategy_(starStrategy),
        userSetConnectionStrategy_(false),
        maxDistance_(0.0),
        indexProperty_(boost::get(boost::vertex_index_t(), g_)),
        stateProperty_(boost::get(vertex_state_t(), g_)),
        radiusProperty_(boost::get(vertex_radius_t(), g_)),
        witnessProperty_(boost::get(vertex_witness_t(), g_)),
        costProperty_(boost::get(vertex_cost_t(), g_)),
        childrenProperty_(boost::get(vertex_children_t(), g_)),
        predecessorProperty_(boost::get(boost::vertex_predecessor_t(), g_)),
        colorProperty_(boost::get(boost::vertex_color_t(), g_)),
        weightProperty_(boost::get(boost::edge_weight_t(), g_)),
        vertexValidityProperty_(boost::get(vertex_flags_t(), g_)),
        edgeValidityProperty_(boost::get(edge_flags_t(), g_)),
        bestCost_(std::numeric_limits<double>::quiet_NaN()),
        iterations_(0),
        increaseIterations_(0),
        BisectionCC_(true),
        rewireFactor_(1.1) {
    specs_.recognizedGoal = base::GOAL_SAMPLEABLE_REGION;
    specs_.approximateSolutions = false;
    specs_.optimizingPaths = true;

    Planner::declareParam<bool>("BisectionCC", this,
                                &DynamicLazyPRMstar::setBisectionCC, std::string("."));
    Planner::declareParam<double>("RewireFactor", this,
                                  &DynamicLazyPRMstar::setRewireFactor, std::string("."));

    addPlannerProgressProperty("iterations INTEGER",
                               boost::bind(&DynamicLazyPRMstar::getIterationCount, this));
    addPlannerProgressProperty("best cost REAL",
                               boost::bind(&DynamicLazyPRMstar::getBestCost, this));
    addPlannerProgressProperty("milestone count INTEGER",
                               boost::bind(&DynamicLazyPRMstar::getMilestoneCountString, this));
    addPlannerProgressProperty("edge count INTEGER",
                               boost::bind(&DynamicLazyPRMstar::getEdgeCountString, this));
}

ompl::geometric::DynamicLazyPRMstar::~DynamicLazyPRMstar() {
}

void ompl::geometric::DynamicLazyPRMstar::setup() {
    Planner::setup();
    tools::SelfConfig sc(si_, getName());
    sc.configurePlannerRange(maxDistance_);

    if (!nn_) {
        nn_.reset(tools::SelfConfig::getDefaultNearestNeighbors<Vertex>(this));
        nn_->setDistanceFunction(boost::bind(&DynamicLazyPRMstar::distanceFunction2, this, _1, _2));
    }

    double dimDbl = static_cast<double>(si_->getStateDimension());
    double prunedMeasure_ = si_->getSpaceMeasure();

    infSampler_.reset();

    k_rrgConstant_ = rewireFactor_ * boost::math::constants::e<double>() + (boost::math::constants::e<double>() /
                                                                            (double)si_->getStateDimension());

    // r_rrg > 2*(1+1/d)^(1/d)*(measure/ballvolume)^(1/d)
    // If we're not using the informed measure, prunedMeasure_ will be set to si_->getSpaceMeasure();
    r_rrgConstant_ = rewireFactor_ * 2.0 * std::pow((1.0 + 1.0/dimDbl) * (prunedMeasure_ / unitNBallMeasure(si_->getStateDimension())), 1.0 / dimDbl);

    // Setup optimization objective
    //
    // If no optimization objective was specified, then default to
    // optimizing path length as computed by the distance() function
    // in the state space.
    if (pdef_) {
        if (pdef_->hasOptimizationObjective()) {
            opt_ = pdef_->getOptimizationObjective();
        } else {
            opt_.reset(new base::PathLengthOptimizationObjective(si_));

            if (!starStrategy_) {
                opt_->setCostThreshold(opt_->infiniteCost());
            }
        }
    } else {
        OMPL_INFORM("%s: problem definition is not set, deferring setup completion...", getName().c_str());
        setup_ = false;
    }
    sampler_ = si_->allocStateSampler();
}

void ompl::geometric::DynamicLazyPRMstar::setRange(double distance) {
    maxDistance_ = distance;

    if (!userSetConnectionStrategy_) {
        connectionStrategy_.clear();
    }

    if (isSetup()) {
        setup();
    }
}

void ompl::geometric::DynamicLazyPRMstar::setMaxNearestNeighbors(unsigned int k) {
    if (starStrategy_) {
        throw Exception("Cannot set the maximum nearest neighbors for " + getName());
    }

    if (!nn_) {
        nn_.reset(tools::SelfConfig::getDefaultNearestNeighbors<Vertex>(this));
        nn_->setDistanceFunction(boost::bind(&DynamicLazyPRMstar::distanceFunction2, this, _1, _2));
    }

    if (!userSetConnectionStrategy_) {
        connectionStrategy_.clear();
    }

    if (isSetup()) {
        setup();
    }
}

void ompl::geometric::DynamicLazyPRMstar::setProblemDefinition(
        const base::ProblemDefinitionPtr &pdef) {
    Planner::setProblemDefinition(pdef);
    clearQuery();
}

void ompl::geometric::DynamicLazyPRMstar::clearQuery() {
    startM_.clear();
    goalM_.clear();
    pis_.restart();
}

void ompl::geometric::DynamicLazyPRMstar::clear() {
    Planner::clear();
    freeMemory();

    if (nn_) {
        nn_->clear();
    }

    clearQuery();

    iterations_ = 0;
    bestCost_ = base::Cost(std::numeric_limits<double>::quiet_NaN());
}

void ompl::geometric::DynamicLazyPRMstar::freeMemory() {
            foreach (Vertex v, boost::vertices(g_)) {
                    si_->freeState(stateProperty_[v]);
                }

    g_.clear();
}

// Add newly sampled vertex and its adjancency edges connected to neigh neighbors.
ompl::geometric::DynamicLazyPRMstar::Vertex ompl::geometric::DynamicLazyPRMstar::addMilestone(
        base::State *state, bool isChecked) {
    Vertex m = boost::add_vertex(g_);
    stateProperty_[m] = state;
    radiusProperty_[m] = std::numeric_limits<double>::infinity();
    costProperty_[m] = std::numeric_limits<double>::infinity();
    childrenProperty_[m] = new std::vector<Vertex>();
    witnessProperty_[m] = nullptr;
    predecessorProperty_[m] = nullptr;
    colorProperty_[m] = 0;
    vertexValidityProperty_[m] = (isChecked) ? VALIDITY_TRUE : VALIDITY_UNKNOWN;

    std::vector<Vertex> neighbors;
    std::vector<double> neighbors_costs;
    const unsigned int max_number_of_neighbors = std::ceil(k_rrgConstant_ * log(static_cast<double>(milestoneCount()) + 1u));

    neighbors.reserve(max_number_of_neighbors);
    neighbors_costs.reserve(max_number_of_neighbors);

    nn_->nearestK(m, max_number_of_neighbors, neighbors);

            foreach (Vertex n, neighbors) {
                    // Symmetricity assumed here, can't use si_->distance here.
                    const double weight = si_->distance(stateProperty_[n], stateProperty_[m]);

                    ompl::base::Cost cost_weight(weight);
                    const Graph::edge_property_type properties(cost_weight);

                    neighborProperty_[m].push_back(type_neighbor(n, weight));
                    neighborProperty_[n].push_back(type_neighbor(m, weight));

                    // If collision-free or optimized well,
                    const Edge &e = boost::add_edge(n, m, properties, g_).first;
                    edgeValidityProperty_[e] = VALIDITY_UNKNOWN;
                }

    nn_->add(m);

    return m;
}

ompl::base::PlannerStatus ompl::geometric::DynamicLazyPRMstar::solve(const
                                                                     base::PlannerTerminationCondition &ptc) {
    // Initial checkup for start/goal configurations.
    checkValidity();

    // Add the valid start states as milestones
    while (const base::State *st = pis_.nextStart()) {
        Vertex st_vert = addMilestone(si_->cloneState(st));
        costProperty_[st_vert] = 0.0; // Initialize with 0 cost.
        startM_.push_back(st_vert);
    }

    if (startM_.size() == 0) {
        OMPL_ERROR("%s: There are no valid initial states!", getName().c_str());
        return base::PlannerStatus::INVALID_START;
    }

    base::GoalSampleableRegion *goal = dynamic_cast<base::GoalSampleableRegion *>
    (pdef_->getGoal().get());

    if (!goal) {
        OMPL_ERROR("%s: Unknown type of goal", getName().c_str());
        return base::PlannerStatus::UNRECOGNIZED_GOAL_TYPE;
    }

    if (!goal->couldSample()) {
        OMPL_ERROR("%s: Insufficient states in sampleable goal region",
                   getName().c_str());
        return base::PlannerStatus::INVALID_GOAL;
    }

    // Ensure there is at least one valid goal state
    if (goal->maxSampleCount() > goalM_.size() || goalM_.empty()) {
        const base::State *st = goalM_.empty() ? pis_.nextGoal(ptc) : pis_.nextGoal();

        if (st) {
            goalM_.push_back(addMilestone(si_->cloneState(st)));
        }

        if (goalM_.empty()) {
            OMPL_ERROR("%s: Unable to find any valid goal states", getName().c_str());
            return base::PlannerStatus::INVALID_GOAL;
        }
    }

    unsigned long int nrStartStates = boost::num_vertices(g_);
    OMPL_INFORM("%s: Starting planning with %lu states already in datastructure",
                getName().c_str(), nrStartStates);

    bestCost_ = opt_->infiniteCost();

    base::State *workState = si_->allocState();
    bool fullyOptimized = false;
    base::PathPtr bestSolution;

    // Only support a single pair of start and goal node.
    Vertex startV = startM_[0];
    Vertex goalV = goalM_[0];
    base::PathPtr solution;

    if (si_->checkMotion(stateProperty_[startV], stateProperty_[goalV])) {
        auto p(std::make_shared<PathGeometric>(si_));
        p->append(stateProperty_[startV]);
        p->append(stateProperty_[goalV]);

        solution = base::PathPtr(p);
        base::PlannerSolution psol(solution);
        psol.setPlannerName(getName());
        // If the solution was optimized, we mark it as such
        psol.setOptimized(opt_, base::Cost(costProperty_[goalV]), fullyOptimized);
        pdef_->addSolutionPath(psol);

        return base::PlannerStatus::EXACT_SOLUTION;
    }

    // Grow roadmap in lazy fashion -- add edges without checking validity
    while (ptc == false) {
        ++iterations_;
        sampler_->sampleUniform(workState);

        if (!si_->isValid(workState)) {
            continue;
        }

        // Add collision-free vertices.
        Vertex addedVertex = addMilestone(si_->cloneState(workState), true);

        // DSPT update.
        Decrease(addedVertex);

        do {
            if (predecessorProperty_[goalV] == nullptr || bestCost_.value() <= costProperty_[goalV])
                break;
            solution = constructSolution(startV, goalV);
        } while (!solution);

        if (solution) {
            // base::Cost c = solution->cost(opt_);
            base::Cost c(costProperty_[goalV]);

            // If it is a non-optimal planner, it will be terminated at here,
            // will keep iterating otherwise.
            if (opt_->isCostBetterThan(c, bestCost_)) {
                bestSolution = solution;
                OMPL_INFORM("%.6lf -> %.6lf", bestCost_.value(), c.value());
                bestCost_ = c;
            }
        }
    }
    si_->freeState(workState);

    if (bestSolution) {
        base::PlannerSolution psol(bestSolution);
        psol.setPlannerName(getName());
        // If the solution was optimized, we mark it as such
        psol.setOptimized(opt_, bestCost_, fullyOptimized);
        pdef_->addSolutionPath(psol);
    }

    OMPL_INFORM("%s: Created %u vertices and %u edges.", getName().c_str(),
                boost::num_vertices(g_) - 1, boost::num_edges(g_));

    return bestSolution ? base::PlannerStatus::EXACT_SOLUTION :
           base::PlannerStatus::TIMEOUT;
}

// Check edge collision checking from v1 to v2 and update witness.
bool ompl::geometric::DynamicLazyPRMstar::checkMotion(const Vertex &v1, const Vertex &v2,
                                                      const double weight) {
    /* Assume motion starts/ends in a valid configuration so v1/v2 are valid */
    bool result = true;
    const base::State *s1 = stateProperty_[v1], *s2 = stateProperty_[v2];
    int nd = si_->getStateSpace()->validSegmentCount(s1, s2);
    double from_radius = (double)nd * radiusProperty_[v1] / weight;
    double to_radius = (double)nd * (1.0 - radiusProperty_[v2] / weight);

    if (nd > 1) {
        /* Temporary storage for the checked state */
        base::State *test = si_->allocState();
        if (!BisectionCC_) {
            // At j == 0 and nd -1 is corresponds to s1 and s2, respectively.
            for (int j = 1 ; j < nd ; j++) {
                si_->getStateSpace()->interpolate(s1, s2, (double)j / (double)nd, test);

                if (!si_->isValid(test)) {
                    result = false;
                    break;
                }
            }
        } else {
            std::queue<std::pair<unsigned int, unsigned int> > q;
            q.push(std::make_pair(1, nd - 1));

            while (!q.empty()) {
                auto range = q.front();
                unsigned int mid;

                mid = (range.first + range.second) / 2;
                si_->getStateSpace()->interpolate(s1, s2, (double)mid / (double)nd, test);

                if (!si_->isValid(test)) {
                    result = false;
                    break;
                }

                q.pop();
                if (range.first < mid)
                    q.push(std::make_pair(range.first, mid - 1));
                if (mid < range.second) {
                    q.push(std::make_pair(mid + 1, range.second));
                } // if mid == first, no more recursion.
            }
        }
    }

    return result;
}

// outedge, inedge? - doesn't matter, need to scan all the neighbors.
void ompl::geometric::DynamicLazyPRMstar::Decrease(const Vertex &v) {
    typedef std::pair<double, Vertex> weight_vertex;
    std::priority_queue<weight_vertex> pq;

    // Initialize cost of v, i.e., finding best parent vertex in G(g_).
    BGL_FORALL_OUTEDGES(v, e, g_, Graph) {
            Vertex w = target(e, g_);
            double weight = weightProperty_[e].value();

            if (costProperty_[v] > costProperty_[w] + weight) {
                predecessorProperty_[v] = w;
                costProperty_[v] = costProperty_[w] + weight;
            }
        }

    // No need to invoke cancelAdoption since v is newly sampled.
    if (predecessorProperty_[v] != nullptr) {
        childrenProperty_[predecessorProperty_[v]]->push_back(v);
    }

    // At this point, v has a best parent. From now on construct its subtree of descendants.

    pq.push(weight_vertex(-costProperty_[v], v)); // Invert the cost value for mimicking min-heap.

    while (!pq.empty()) {
        weight_vertex top = pq.top();
        pq.pop();

        double cost = -top.first; // Invert the cost value to be like min-heap.
        Vertex vert = top.second;

        if (cost > costProperty_[vert]) {
            continue;
        }

        BGL_FORALL_OUTEDGES(vert, e, g_, Graph) {
                Vertex w = target(e, g_);
                double weight = weightProperty_[e].value();
                double cost_w = costProperty_[w];

                if (cost_w > cost + weight) {
                    costProperty_[w] = cost + weight;
                    cancelAdoption(w);

                    predecessorProperty_[w] = vert;
                    childrenProperty_[vert]->push_back(w);
                    pq.push(weight_vertex(-costProperty_[w], w));
                }
            }
    }

    // Now, DSPT is stable.
}

#define RED (increaseIterations_ + 1) // I know, it's bad #define.

void ompl::geometric::DynamicLazyPRMstar::Increase(const Vertex vs) {
    // <Step 1. Preparation.
    // white is used for color of each vertex without initialization.
    // For each iteration, white is increased by 1, thus we can use it as
    // equal to or less than 'white' means 'white' color, 'red' otherwise.
    increaseIterations_ += 1;

    std::vector<Vertex> reds;
    typedef std::pair<double, Vertex> weight_vertex;
    std::priority_queue<weight_vertex> pq; //  Max-heap by default.

    pq.push(weight_vertex(-costProperty_[vs], vs));  // It works as if it is min-heap.

    // <Step 2. Coloring
    while (!pq.empty()) {
        weight_vertex top = pq.top();
        pq.pop();

        double cost = -top.first;
        Vertex vert = top.second;

        if (cost > costProperty_[vert]) {
            continue;  // Instead of heap-improve
        }

        colorProperty_[vert] = RED; // Set to 'red'
        reds.push_back(vert);
        // Even with multiple starting red nodes, there will be no re-visit since each starting node is
        // a root node of sub'tree' in DSPT. That is, if statement within for loop might be useless.
        // Someone would be curious, e.g., then why do we have to use priority queue in step2 ?
        // Just for 'pink' case. Yeap. We need to identify all the other parent candidates are red or not
        // prior to checking current node.
        std::vector<Vertex> *children = childrenProperty_[vert];

        for (unsigned int i = 0; i < children->size(); i++) {
            pq.push(weight_vertex(-costProperty_[(*children)[i]], (*children)[i]));
        }
    }

    // 'pq' is empty at here.

    // <Step 3-a. Find best non-red parent for each red node.
    for (unsigned int i = 0; i < reds.size(); i++) {
        // Cost/predecessor initialization.
        costProperty_[reds[i]] = std::numeric_limits<double>::infinity();
        cancelAdoption(reds[i]);

        BGL_FORALL_OUTEDGES(reds[i], e, g_, Graph) {
                Vertex w = target(e, g_);
                double weight = weightProperty_[e].value();

                if (colorProperty_[w] == RED) {
                    continue;  // If red, put aside for a while.
                }

                if (costProperty_[reds[i]] > costProperty_[w] + weight) {
                    costProperty_[reds[i]] = costProperty_[w] + weight;
                    predecessorProperty_[reds[i]] = w;
                }
            }

        if (predecessorProperty_[reds[i]] != nullptr) {
            childrenProperty_[predecessorProperty_[reds[i]]]->push_back(reds[i]);
        }

        pq.push(weight_vertex(-costProperty_[reds[i]], reds[i]));
    }

    // <Step 3-b. Propagate the changes; rewiring for 'red' nodes whether it can replace
    // existing parent node of near neighbors.
    while (!pq.empty()) {
        weight_vertex top = pq.top();
        pq.pop();

        double cost = -top.first;
        Vertex vert = top.second;

        if (costProperty_[vert] < cost) {
            continue;
        }

        BGL_FORALL_OUTEDGES(vert, e, g_, Graph) {
                Vertex w = target(e, g_);
                double weight = weightProperty_[e].value();

                if (colorProperty_[w] != RED) {
                    continue;  // If not red, then skip.
                }

                if (cost + weight < costProperty_[w]) {
                    costProperty_[w] = cost + weight;

                    cancelAdoption(w);

                    predecessorProperty_[w] = vert;
                    childrenProperty_[vert]->push_back(w);
                    pq.push(weight_vertex(-costProperty_[w], w));
                }
            }
    }

    // The end!
    // colorProperty_ is not necessary to be cleansed out, just increase variable, 'RED'.
}

void ompl::geometric::DynamicLazyPRMstar::cancelAdoption(const Vertex &child) {
    if (predecessorProperty_[child] == nullptr)
        return;

    std::vector<Vertex> *children = childrenProperty_[predecessorProperty_[child]];

    for (unsigned int i = 0; i < children->size(); i++) if ((*children)[i] == child) {
            std::swap((*children)[i], children->back());
            children->pop_back();
            break;
        }

    predecessorProperty_[child] = nullptr;
}

// Vertex first.
ompl::base::PathPtr ompl::geometric::DynamicLazyPRMstar::constructSolution(
        const Vertex &start, const Vertex &goal) {
    std::vector<Vertex> solution_path;

    // Construct a solution from DSPT.
    for (Vertex vert = goal; vert != nullptr; vert = predecessorProperty_[vert])
        solution_path.push_back(vert);

    if (solution_path.empty())
        return base::PathPtr();

    // Goal = 0, Start = n - 1.

    auto from = solution_path.rbegin();
    for (auto to = from + 1; to != solution_path.rend(); ++to) {
        Edge e = boost::lookup_edge(*from, *to, g_).first; // Exhaustive search O(E) at worst case.
        unsigned int &evd = edgeValidityProperty_[e];

        if ((evd & VALIDITY_TRUE) == 0) { // Unknown
            bool result = true;

            result &= si_->checkMotion(stateProperty_[*from], stateProperty_[*to]);

            if (result) {
                evd |= VALIDITY_TRUE;
            } else {
                boost::remove_edge(e, g_); // O(log(E/V)) time

                cancelAdoption(*to);
                Increase(*to);
                return base::PathPtr();
            }
        }

        from = to;
    }

    auto p(std::make_shared<PathGeometric>(si_));
    // Feasible path is found, fetch optimized edges if possible.
    for (std::vector<Vertex>::const_reverse_iterator sol = solution_path.rbegin();
         sol != solution_path.rend(); ++sol) {
        p->append(stateProperty_[*sol]);
    }

    return base::PathPtr(p);
}

void ompl::geometric::DynamicLazyPRMstar::getPlannerData(base::PlannerData &data)
const {
    Planner::getPlannerData(data);
    // Caution : it handles directional information regardless of the search graph setting
    //           which is undirectional graph.
}


double ompl::geometric::DynamicLazyPRMstar::distanceFunction(const base::State *a, const base::State *b) const {
    return si_->distance(a, b);
}

double ompl::geometric::DynamicLazyPRMstar::distanceFunction2(const Vertex a, const Vertex b) const {
    return si_->distance(stateProperty_[a], stateProperty_[b]);
}