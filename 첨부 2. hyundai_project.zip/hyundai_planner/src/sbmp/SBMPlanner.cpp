/* Author: Mincheul Kang */

#include <hyundai_planner/sbmp/SBMPlanner.h>
#include <hyundai_planner/sbmp/DynamicLazyPRMstar.h>

#include <sensor_msgs/JointState.h>
#include <ros/ros.h>
#include <vector>
#include <iostream>

template <typename T, typename A>
int arg_max(std::vector<T, A> const& vec) {
    return static_cast<int>(std::distance(vec.begin(), max_element(vec.begin(), vec.end())));
}

SBMPlanner::SBMPlanner(const std::string &planning_group, planning_scene::PlanningScenePtr& planning_scene){
    planning_scene_ = planning_scene;
    planning_group_ = planning_group;

    robot_model_loader::RobotModelLoader robot_model_loader("robot_description");
    robot_model::RobotModelPtr robot_model = robot_model_loader.getModel();
    robot_state::RobotStatePtr robot_state(new robot_state::RobotState(robot_model));
    const robot_state::JointModelGroup* joint_model_group = robot_state->getJointModelGroup(planning_group);

    // state space
    robot_model::JointBoundsVector joint_bounds;
    joint_bounds = joint_model_group->getActiveJointModelsBounds();
    num_dof_ = (unsigned int)joint_bounds.size();
    std::vector<std::string> indices = joint_model_group->getActiveJointModelNames();

    // Set joint type
    ompl::base::CompoundStateSpace *newSpace = new ompl::base::CompoundStateSpace();
    std::vector<std::pair<double, double> > bounds;
    for (size_t joint_i = 0; joint_i < joint_bounds.size(); joint_i++) {
        const robot_model::JointModel::Bounds& b = *joint_bounds[joint_i];

        std::pair<double, double> bb = std::make_pair(b[0].min_position_, b[0].max_position_);
        bounds.push_back(bb);
        if(b[0].min_position_ == -M_PI && b[0].max_position_ == M_PI){
            newSpace->addSubspace(ompl::base::StateSpacePtr(new ompl::base::SO2StateSpace()), 1.0);
            is_continuous_.push_back(true);
        }
        else{
            ompl::base::RealVectorStateSpace *rvs = new ompl::base::RealVectorStateSpace(1);
            rvs->setBounds(b[0].min_position_, b[0].max_position_);
            newSpace->addSubspace(ompl::base::StateSpacePtr(rvs), 1.0);
            is_continuous_.push_back(false);
        }
    }

    //// ompl
    state_space_.reset(newSpace);
    state_space_->setup();

    // simple setup
    simple_setup_.reset(new ompl::geometric::SimpleSetup(state_space_));
    // state validity checker
    StateValidityCheckerPtr validity_checker;
    validity_checker.reset(new StateValidityChecker(simple_setup_->getSpaceInformation(), planning_scene_, planning_group));
    simple_setup_->setStateValidityChecker(std::static_pointer_cast<ompl::base::StateValidityChecker>(validity_checker));
}

bool SBMPlanner::solve(const std::vector<double> &s_conf, const std::vector<double> &g_conf, const double planning_time, double &elapsed_time){
    typedef ompl::base::ScopedState<ompl::base::StateSpace> ScopedState;

    // set initial state
    ScopedState q_start(state_space_);
    for (size_t i = 0; i < num_dof_; i++) {
        q_start[i] = s_conf[i];
    }
    simple_setup_->addStartState(q_start);

    // set goal state
    ScopedState q_goal(state_space_);
    for (size_t i = 0; i < num_dof_; i++) {
        q_goal[i] = g_conf[i];
    }
    simple_setup_->setGoalState(q_goal);
    simple_setup_->setStartAndGoalStates(q_start, q_goal);

    simple_setup_->getSpaceInformation()->setMotionValidator(std::make_shared<ompl::base::DiscreteMotionValidator>(simple_setup_->getSpaceInformation()));

    // set planner
    simple_setup_->setPlanner(ompl::base::PlannerPtr(new ompl::geometric::DynamicLazyPRMstar(simple_setup_->getSpaceInformation())));
    ros::WallTime start_time = ros::WallTime::now();
    auto result = simple_setup_->solve(ompl::base::timedPlannerTerminationCondition(planning_time));
    ros::WallTime end_time = ros::WallTime::now();
    elapsed_time = (end_time - start_time).toSec();

    return result;
}

bool SBMPlanner::solve(const std::vector<double> &s_conf, const std::vector<double> &g_conf, const double planning_time,
                       KinematicsSolverPtr &ksolver, const std::vector<std::pair<double, double> > &constraints,
                       double &elapsed_time){
    typedef ompl::base::ScopedState<ompl::base::StateSpace> ScopedState;

    // set initial state
    ScopedState q_start(state_space_);
    for (size_t i = 0; i < num_dof_; i++) {
        q_start[i] = s_conf[i];
    }
    simple_setup_->addStartState(q_start);

    // set goal state
    ScopedState q_goal(state_space_);
    for (size_t i = 0; i < num_dof_; i++) {
        q_goal[i] = g_conf[i];
    }
    simple_setup_->setGoalState(q_goal);
    simple_setup_->setStartAndGoalStates(q_start, q_goal);

    simple_setup_->getSpaceInformation()->setMotionValidator(std::make_shared<ConstrainedMotionValidator>(simple_setup_->getSpaceInformation(), ksolver, is_continuous_, constraints, s_conf));

    // set planner
    simple_setup_->setPlanner(ompl::base::PlannerPtr(new ompl::geometric::DynamicLazyPRMstar(simple_setup_->getSpaceInformation())));
    ros::WallTime start_time = ros::WallTime::now();
    auto result = simple_setup_->solve(ompl::base::timedPlannerTerminationCondition(planning_time));
    ros::WallTime end_time = ros::WallTime::now();
    elapsed_time = (end_time - start_time).toSec();

    return result;
}

void SBMPlanner::pathVisualization(int N_interpol, float dip_dt){
    ros::NodeHandle node_handle("~");
    ros::Publisher joint_pub = node_handle.advertise<sensor_msgs::JointState>("/joint_states", 1000);
    sensor_msgs::JointState joint_state;

    if (simple_setup_->haveSolutionPath()) {
        ompl::geometric::PathGeometric &p = simple_setup_->getSolutionPath();
        simple_setup_->getPathSimplifier()->simplifyMax(p);
        ros::Publisher display_pub = node_handle.advertise<moveit_msgs::DisplayTrajectory>("/move_group/display_planned_path", 1, true);
        moveit_msgs::DisplayTrajectory display_trajectory;
        moveit_msgs::RobotTrajectory robot_traj;
        const moveit::core::JointModelGroup* model_group = planning_scene_->getRobotModel()->getJointModelGroup(planning_group_);
        const std::vector<std::string>& active_joint_names = model_group->getActiveJointModelNames();

        // Display Waypoints (non-interpolated version) -- Moveit --
        robot_traj.joint_trajectory.joint_names = active_joint_names;
        robot_traj.joint_trajectory.points.resize(p.getStateCount());
        for(uint i = 0; i < p.getStateCount(); i++){
            auto *rstate = static_cast<ompl::base::CompoundState *>(p.getState(i));
            robot_traj.joint_trajectory.points[i].positions.resize(num_dof_);

            for(uint k = 0; k < num_dof_; k++){
                if(is_continuous_[k])
                    robot_traj.joint_trajectory.points[i].positions[k] = rstate->as<ompl::base::SO2StateSpace::StateType>(k)->value;
                else
                    robot_traj.joint_trajectory.points[i].positions[k] = rstate->as<ompl::base::RealVectorStateSpace::StateType>(k)->values[0];
            }
            robot_traj.joint_trajectory.points[i].time_from_start = ros::Duration(0.0);
        }
        display_trajectory.trajectory.push_back(robot_traj);
        display_pub.publish(display_trajectory);
        ros::Duration(0.001).sleep();

        // interpolate waypoints (4,6: continuous)
        std::vector<std::vector<double>> interpolated_config_list;

        ompl::base::State *base = simple_setup_->getSpaceInformation()->allocState();
        for(uint i = 0; i < p.getStateCount()-1; i++){
            int nd = N_interpol;
            for(uint j = 0; j <= nd; j++){
                simple_setup_->getSpaceInformation()->getStateSpace()->interpolate(p.getState(i), p.getState(i+1), (double)j / (double)nd, base);
                auto *rstate = static_cast<ompl::base::CompoundState *>(base);
                std::vector<double> cfg;
                for(uint k = 0; k < num_dof_; k++){
                    if(is_continuous_[k])
                        cfg.push_back(rstate->as<ompl::base::SO2StateSpace::StateType>(k)->value);
                    else
                        cfg.push_back(rstate->as<ompl::base::RealVectorStateSpace::StateType>(k)->values[0]);
                }
                interpolated_config_list.push_back(cfg);
            }
        }

        // Display Trajectory (interpolated version) -- Moveit --
        robot_traj.joint_trajectory.joint_names = active_joint_names;
        robot_traj.joint_trajectory.points.resize(interpolated_config_list.size());
        for(uint i=0; i<interpolated_config_list.size(); i++){
            robot_traj.joint_trajectory.points[i].positions.resize(num_dof_);

            for(uint j = 0; j < num_dof_; j++)
                robot_traj.joint_trajectory.points[i].positions[j] = interpolated_config_list[i][j];
            robot_traj.joint_trajectory.points[i].time_from_start = ros::Duration(0.0);
        }
        display_trajectory.trajectory.push_back(robot_traj);
        display_pub.publish(display_trajectory);
        ros::Duration(0.001).sleep();

        // Display Trajectory -- Publish Joint_states to update robot's state in the move_group --
        for(uint i=0; i<interpolated_config_list.size(); i++){
            joint_state.header.stamp = ros::Time::now();
            joint_state.name.resize(num_dof_);
            joint_state.position.resize(num_dof_);

            for(uint j = 0; j < num_dof_; j++){
                joint_state.name[j] = active_joint_names[j];
                joint_state.position[j] = interpolated_config_list[i][j];
            }
            joint_pub.publish(joint_state);
            ros::Duration(dip_dt).sleep();
        }

        // re-publish end configuration 10 times more for guarantee of the update on the simulation.
        for(uint i=0; i<10; i++){
            joint_state.header.stamp = ros::Time::now();
            joint_state.name.resize(num_dof_);
            joint_state.position.resize(num_dof_);

            for(uint j = 0; j < num_dof_; j++){
                joint_state.name[j] = active_joint_names[j];
                joint_state.position[j] = interpolated_config_list[interpolated_config_list.size()-1][j];
            }
            joint_pub.publish(joint_state);
            ros::Duration(dip_dt).sleep();
        }
    }
}