/* Author: Mincheul Kang */

#include <ros/ros.h>
#include <hyundai_planner/KinematicsSolver.h>
#include <math.h>

bool areEqualAbs(double a, double b, double epsilon) {
    return (std::abs(a - b) <= epsilon);
}

KinematicsSolver::KinematicsSolver(std::string base_link, std::string tip_link, const unsigned int num_dof,
                                   planning_scene::PlanningScenePtr& planning_scene,
                                   const std::string& PLANNING_GROUP,
                                   collision_detection::CollisionRequest &collision_request,
                                   robot_state::RobotStatePtr robot_state) {
    double eps = 1e-5;
    num_dof_ = num_dof;
    planning_scene_ = planning_scene;
    PLANNING_GROUP_ = PLANNING_GROUP;
    collision_request_ = collision_request;
    robot_state_ = robot_state;

    tracik_solver_.reset(new TRAC_IK::TRAC_IK (base_link, tip_link, "/robot_description", 0.005, eps));
    bool valid = tracik_solver_->getKDLChain(chain_);
    valid = tracik_solver_->getKDLLimits(ll_, ul_);
    fk_solver_.reset(new KDL::ChainFkSolverPos_recursive(chain_));
    jacsolver_.reset(new KDL::ChainJntToJacSolver(chain_));
}

bool KinematicsSolver::ikSolver(const KDL::JntArray& q_init, const KDL::Frame& p_in, KDL::JntArray& q_out) {
    int rc = tracik_solver_->CartToJnt(q_init, p_in, q_out);
    if(rc < 0){
        return false;
    }
    return true;
}

void KinematicsSolver::fkSolver(const KDL::JntArray& q, KDL::Frame& p){
    fk_solver_->JntToCart(q, p);
}

void KinematicsSolver::computeJacobian(const KDL::JntArray& q, KDL::Jacobian& jac){
    jacsolver_->JntToJac(q, jac);
}

std::vector<double>
KinematicsSolver::getGoalConfigs(std::vector<double> cur_conf, const double goal_x, const double goal_y, const double goal_z, const double goal_roll, const double goal_pitch, const double goal_yaw, const double offset_z) {
    moveit::planning_interface::MoveGroupInterface move_group(PLANNING_GROUP_);
    std::vector<double> random_config = move_group.getRandomJointValues();
    KDL::JntArray q_init(num_dof_);
    for(uint i=0; i<num_dof_; i++)
        q_init(i) = random_config[i];
    KDL::Frame g_xyz;
    KDL::JntArray q_goal(num_dof_);
    std::vector<double> g_conf(num_dof_, 0.0);

    // [IK] inverse kinematic from goal_xyz to q_goal
    g_xyz.p.data[0] = goal_x;
    g_xyz.p.data[1] = goal_y;
    g_xyz.p.data[2] = goal_z + offset_z;
    g_xyz.M = g_xyz.M.RPY(goal_roll,goal_pitch,goal_yaw);

    uint INVK_COUNT = 10;
    uint count = 0;
    while(true){
        count++;
        if(count == (INVK_COUNT+1)){
            // Fail to solve the inverse kinematic within INVK_COUNT times with each different random init config.
            for(int i = 0; i < num_dof_; i++){
                g_conf[i] = 0.0;
            }
            return g_conf; // return all 0 to notify the outside function of the ik failure.
        }

        // Run IK solver.
        if(!this->ikSolver(q_init, g_xyz, q_goal))
        { // fail to find IK solution...
            //ROS_ERROR_STREAM("[IK] Fail to find IK solution. remaining count: "<<count);
            continue;
        }else{ // succeed to find goal config. (without considering obstacles around the ambient space)
            for(int i = 0; i < num_dof_; i++){
                g_conf[i] = q_goal(i);
            }
        }

        // [Post processing] the goal configuration with respect to the related task and robot.
        if(g_conf[2]<0.5) // [1] third joint constraint to keep the robot not flipped.
        {
            if(std::abs(g_conf[4] - cur_conf[4]) < (M_PI*2/3)) // [2] Don't let the wrist turn over to prevent the box from overturning.
            {
                if (this->isValid(g_conf))  // [3] Check if a collision occurs with obstacles.
                {
                    // 4,6 joint (continuous) fitted into -pi to pi range.
                    g_conf[3] = atan2(sin(g_conf[3]), cos(g_conf[3]));
                    g_conf[5] = atan2(sin(g_conf[5]), cos(g_conf[5]));

                    // Adjust the base revolute joint to make sequential configuration consistent ( 3.1415.. <=/=> -3.1415.. )
                    if(areEqualAbs(std::abs(cur_conf[0]),M_PI,0.001) && areEqualAbs(std::abs(g_conf[0]),M_PI,0.001)){
                        //ROS_WARN("[IK] Adjust the base revolute joint.");
                        g_conf[0] = cur_conf[0];
                    }

                    // Bounding the joints to prevent error messages that occur due to subtle differences in the decimal point. (Ex. -3.141592691, -3.141592654)
                    for (int j = 0; j < num_dof_; j++) {
                        std::cout.precision(10);
                        if (g_conf[j] > robot_state_->getRobotModel()->getJointModelGroups()[0]->getActiveJointModelsBounds()[j][0][0].max_position_) {
                            std::cout<< g_conf[j]<<", "<<robot_state_->getRobotModel()->getJointModelGroups()[0]->getActiveJointModelsBounds()[j][0][0].max_position_<<std::endl;
                            /*g_conf[j] = robot_state_->getRobotModel()->getJointModelGroups()[0]->getActiveJointModelsBounds()[j][0][0].max_position_;*/
                        }else if(g_conf[j] < robot_state_->getRobotModel()->getJointModelGroups()[0]->getActiveJointModelsBounds()[j][0][0].min_position_) {
                            std::cout<< g_conf[j]<<", "<< robot_state_->getRobotModel()->getJointModelGroups()[0]->getActiveJointModelsBounds()[j][0][0].min_position_<<std::endl;
                            /*g_conf[j] = robot_state_->getRobotModel()->getJointModelGroups()[0]->getActiveJointModelsBounds()[j][0][0].min_position_;*/
                        }
                    }
                    return g_conf; // Done.
                }else
                { // [3] Collision.
                    continue;
                }
            }else
            { // [2] When joint 5 rotates more than 2/3pi, the box is overturned.
                continue;
            }
        }else
        { // [1] The 3rd joint is out of range. (The robot arm is turned over.)
            continue;
        }
    }
}

bool KinematicsSolver::isValid(const std::vector<double> &values) {
    collision_detection::CollisionResult collision_result;
    collision_result.clear();

    robot_state::RobotState robot_state = planning_scene_->getCurrentStateNonConst();
    robot_state.setJointGroupPositions(PLANNING_GROUP_, values);
    planning_scene_->checkCollision(collision_request_, collision_result, robot_state);

    return !collision_result.collision;
}