/* Author: Mincheul Kang */

#include <ros/ros.h>
#include <boost/date_time.hpp>
#include <boost/program_options.hpp>

// MoveIt!
#include <moveit/robot_model_loader/robot_model_loader.h>
#include <moveit/planning_scene/planning_scene.h>
#include <moveit_visual_tools/moveit_visual_tools.h>
#include <moveit/move_group_interface/move_group_interface.h>

// hyundai_planner
#include <hyundai_planner/Scene.h>
#include <hyundai_planner/KinematicsSolver.h>
#include <hyundai_planner/sbmp/SBMPlanner.h>
#include <hyundai_planner/obmp/OBMPlanner.h>
#include <hyundai_planner/tp/TaskPlanner.h>

#include <rviz_visual_tools/rviz_visual_tools.h>


int main(int argc, char** argv) {
    ros::init(argc, argv, "hyundai_planner");
    ros::NodeHandle node_handle("~");

    //// Please set your group in moveit!
    const std::string PLANNING_GROUP = "hyundai_arm";
    robot_model_loader::RobotModelLoader robot_model_loader("robot_description");
    robot_model::RobotModelPtr robot_model = robot_model_loader.getModel();
    robot_state::RobotStatePtr robot_state(new robot_state::RobotState(robot_model));
    planning_scene::PlanningScenePtr planning_scene(new planning_scene::PlanningScene(robot_model));
    const robot_state::JointModelGroup* joint_model_group = robot_state->getJointModelGroup(PLANNING_GROUP);
    unsigned int num_dof = joint_model_group->getVariableCount();
    moveit::planning_interface::MoveGroupInterface move_group(PLANNING_GROUP);

    // parsing arguments
    std::string scene_num;
    namespace po = boost::program_options;
    po::options_description desc("\nAllowed options");
    desc.add_options()
            ("help,h", " Produce a help screen")
            ("scene_num,s", boost::program_options::value<std::string>(), " Select a scene number: [1,2,3]");
    po::variables_map vm;
    po::store(parse_command_line(argc, argv, desc), vm);
    if(vm.count("help")) {
        std::cout << "\nUsage: rosrun hyundai_planner main [options]\n";
        std::cout << desc;
        return 0;
    }
    else if (vm.count("scene_num")){
        scene_num = vm["scene_num"].as<std::string>();
        std::cout << "Select: scene" << scene_num << ".txt" << std::endl;
    }

    // moveit planning scene
    ROS_INFO("Start moveit planning scene");
    ScenePtr scene(new Scene(planning_scene, "hyundai_base"));
    scene->addCollisionObjects(scene_num);
    scene->updateGlobalCollisionScene();
    ROS_INFO("End moveit planning scene");

    // collision checker
    ROS_INFO("Start collision checker");
    collision_detection::CollisionRequest collision_request;
    collision_request.group_name = PLANNING_GROUP;
    collision_request.contacts = true;
    collision_request.max_contacts = 100;
    collision_request.max_contacts_per_pair = 1;
    collision_request.verbose = false;
    ROS_INFO("End collision checker");


    // ========================= TASK PLANNING =========================
    std::string project_path = ros::package::getPath("hyundai_planner");
    std::string problem_path = project_path + "/src/tp/problem.pddl";
    std::string domain_path = project_path + "/src/tp/domain.pddl";
    std::string soln_file_path = project_path + "/src/tp/problem.pddl.soln";
    std::string tp_exe = project_path + "/src/tp/ff -f " + problem_path + " -o " + domain_path;
    std::system(tp_exe.c_str()); // Generate a task planning solution.

    TaskPlanner task_planner(soln_file_path);
    task_planner.SetProjectPath(project_path);
    task_planner.GetTasks();
    task_planner.ParseTask();
    task_planner.GenerateParsedFile();
    task_planner.ParseStartGoalConfig();
    auto planned_list = task_planner.GetConfigs();

    // ========================= PATH PLANNING =========================
    // [Preprocessing] convert planned list tuple to double vector -- MS
    std::vector<std::vector<double>> planned_config_list;
    uint num_plan = planned_list.size();
    for(uint i = 0 ; i < num_plan ; i++){
        auto start_xyz = std::get<1>(planned_list[i]);
        auto goal_xyz = std::get<2>(planned_list[i]);

        std::vector<double> cfg;
        cfg.push_back( std::get<0>(start_xyz) );
        cfg.push_back( std::get<1>(start_xyz) );
        cfg.push_back( std::get<2>(start_xyz) );
        planned_config_list.push_back(cfg);

        cfg.clear();
        cfg.push_back( std::get<0>(goal_xyz) );
        cfg.push_back( std::get<1>(goal_xyz) );
        cfg.push_back( std::get<2>(goal_xyz) );
        planned_config_list.push_back(cfg);
    }
    uint num_path = planned_config_list.size();


    // Rviz for prompting the error message
    std::string error_msg = "Cannot find valid goal configuration. Push 'continue' to shutdown the system.";
    rviz_visual_tools::RvizVisualToolsPtr rviz(new rviz_visual_tools::RvizVisualTools("hyundai_base","/rviz_visual_markers"));


    // [(Constrained) Sampling-based motion planner] (SBMP)
    SBMPlannerPtr sbmp(new SBMPlanner(PLANNING_GROUP, planning_scene));
    // [Optimization-based motion planner] (OBMP)
    OBMPlannerPtr obmp(new OBMPlanner(PLANNING_GROUP, planning_scene, scene));


    // [Kinematic solver]
    std::string base_link = "hyundai_base";
    std::string tip_link = "hyundai_flange";
    KinematicsSolverPtr solver(new KinematicsSolver(base_link, tip_link, num_dof, planning_scene, PLANNING_GROUP, collision_request, robot_state));


    // [Constraints] for constrained sampling based motion planning (CSBMP)
    std::vector<std::pair<double, double> > constraints;
    constraints.push_back(std::make_pair<double, double>(0.0, 0.0));
    constraints.push_back(std::make_pair<double, double>(0.0, 0.0));
    constraints.push_back(std::make_pair<double, double>(0.0, 0.0));
    constraints.push_back(std::make_pair<double, double>(-M_PI/6, M_PI/6));
    constraints.push_back(std::make_pair<double, double>(-M_PI/6, M_PI/6));
    constraints.push_back(std::make_pair<double, double>(0.0, 0.0));

    // Log variables for logging planning results
    double Log_planning_time[num_path*4];
    double Log_average_planning_time = 0.0;
    int Log_idx = 0;
    int print_dec_point = 3;

    // [Start Planning]
    std::vector<double> init_config{0.0, M_PI/2, 0.0, 0.0, 0.0, 0.0};
    std::vector<double> cur_conf(num_dof, 0.0);
    for(uint j=0; j<num_dof; j++)
        cur_conf[j] = init_config[j];

    std::cout<<std::endl;
    // [Planning] plan the path from 'current_configuration' to 'goal_configuration'
    ROS_INFO("========================= START PATH PLANNING =========================");
    for ( uint i = 0 ; i < num_path ; i++){
        ROS_WARN_STREAM("[Main] ------------ Main loop ["<<i<<"/"<<num_path<<"] ------------ ");

        if(i%2==0){ // -------------------- Move step --------------------
            ROS_WARN_STREAM("[Main - Move] Move the manipulator to the box");
            std::vector<double> g_conf; // 0.43m above the center of the target box
            double time_limit = 0.1;
            int Remaining_attempts_for_IK = 100; // remaining attempts to find a goal config ( in case of the failure due to being the object at the goal position already )
            double elapsed_time = 0.0;
            while(true){
                // Fail to find the Goal config in 100 attempts. --> Prompt the error message and exit.
                if(Remaining_attempts_for_IK==0){
                    rviz->prompt(error_msg);
                    exit(0);
                }
                // Try to get the goal configuration [Joint space] from the end-effector goal pose [Cartesian space]:: the inverse kinematic
                g_conf = solver->getGoalConfigs(cur_conf,
                                                planned_config_list[i][0],
                                                planned_config_list[i][1],
                                                planned_config_list[i][2],
                                                M_PI, M_PI/2, 0.0,
                                                0.43);
                // Fail to solve the inverse kinematic of the goal pose
                if(g_conf[0]==0 && g_conf[1]==0 && g_conf[2]==0 && g_conf[3]==0 && g_conf[4]==0 && g_conf[5]==0){
                    Remaining_attempts_for_IK--;
                    ROS_WARN_STREAM("[Main - IK] fail to solve IK... (remaining attempts: "<<Remaining_attempts_for_IK<<")");
                    continue;
                }else{
                    ROS_INFO_STREAM("[Main - IK] Succeed to find the goal configuration.");
                }
                ROS_INFO_STREAM("[Main - Planning] \n"
                                << "# Start configuration: ["<<cur_conf[0]<<", "<<cur_conf[1]<<", "<<cur_conf[2]<<", "<<cur_conf[3]<<", "<<cur_conf[4]<<", "<<cur_conf[5]<<"] \n"
                                << "# Goal  configuration: ["<<g_conf[0]<<", "<<g_conf[1]<<", "<<g_conf[2]<<", "<<g_conf[3]<<", "<<g_conf[4]<<", "<<g_conf[5]<<"]");
                bool planning_result; // PLANNING
                if(strcmp(argv[1],"sbmp")==0 || strcmp(argv[1],"csbmp")==0){
                    ROS_INFO("[Main - Planning] < Start sbmp planning >");
                    planning_result = sbmp->solve(cur_conf, g_conf, time_limit, elapsed_time);
                }
                else if(strcmp(argv[1],"obmp")==0) {
                    ROS_INFO("[Main - Planning] < Start obmp planning >");
                    planning_result = obmp->solve(cur_conf, g_conf, time_limit, "", elapsed_time, solver, constraints, false);
                }
                ROS_INFO_STREAM("[Main - Planning] planning_result: "<<planning_result);
                if(planning_result) {
                    ROS_INFO_STREAM("[Main - Planning] Success to find path in: "<<elapsed_time);
                    // for debugging and logging the result
                    Log_planning_time[Log_idx] = elapsed_time;
                    Log_average_planning_time += elapsed_time;
                    Log_idx++;
                    std::stringstream ss;
                    ss << std::fixed << std::setprecision(print_dec_point) << "\n[Log - Used_times]: ";
                    for(uint q = 0; q<Log_idx; q++){
                        if((q+1)%4==0){
                            ss << Log_planning_time[q]<<"| ";
                        }else{
                            ss << Log_planning_time[q]<<", ";
                        }
                    }
                    ss << "\n[Log - Avg_time]: "<<Log_average_planning_time/(Log_idx) << " seconds";
                    ROS_INFO_STREAM(ss.str());
                    break;
                }
                time_limit += 0.1;
            }
            // VISUALIZATION
            if(strcmp(argv[1],"sbmp")==0 || strcmp(argv[1],"csbmp")==0){
                sbmp->pathVisualization(100, 0.02);
            }
            else if(strcmp(argv[1],"obmp")==0){
                obmp->pathVisualization(0.02); // N_interpolation is fixed to 101.
            }
            // Move to the next step.
            for(uint j=0; j<num_dof; j++){
                cur_conf[j] = g_conf[j];
            }
            ROS_INFO_STREAM("[Main - Move] Done.\n");
            ros::Duration(0.1).sleep(); // Pause for a moment for visualization.
        }
        else{ // -------------------- Pick and Place (PP) step --------------------
            ROS_WARN_STREAM("[Main - PP] Pick and place the box");
            std::string collision_object_id = std::get<0>(planned_list[i/2]); // a target box id
            boost::algorithm::to_lower(collision_object_id);
            // Sub-steps for pick and place process [1~5]

            // [1] Remove box from world visually.
            scene->removeCollisionObject(collision_object_id);

            // [2] Attach box to the robot's end-effector.
            scene->addAttachedCollisionObject(collision_object_id);

            // [3] plan the path.
            // divide pick and place task into 3-steps ( pregrasp - move - place ) [k: 0~2]
            for(int k=0; k<3; k++){
                if(k==0){
                    ROS_WARN_STREAM("[Main - PP] -- Planning to pregrasp the box (k: "<<k<<") --");
                }else if(k==1){
                    ROS_WARN_STREAM("[Main - PP] -- Planning to move the box to the other side (k: "<<k<<") --");
                }else{
                    ROS_WARN_STREAM("[Main - PP] -- Planning to place the box to the target pose (k: "<<k<<") --");
                }
                std::vector<double> g_conf;
                double time_limit = 0.1;
                double elapsed_time = 0.0;
                int Remaining_attempts_for_IK = 100;
                while(true){
                    // Fail to find the Goal config in 100 attempts. --> Prompt the error message and exit.
                    if(Remaining_attempts_for_IK==0){
                        rviz->prompt(error_msg);
                        exit(0);
                    }
                    // Try to get the goal configuration [Joint space] from the end-effector goal pose [Cartesian space]:: the inverse kinematic
                    if(k==0){ // pregrasp goal config
                        g_conf = solver->getGoalConfigs(   cur_conf,
                                                           -0.9,
                                                           planned_config_list[i-1][1],
                                                           planned_config_list[i-1][2],
                                                           M_PI, M_PI/2, 0.0,
                                                           2.0-planned_config_list[i-1][2]);
                    }
                    else if(k==1){ // move goal config
                        g_conf = solver->getGoalConfigs(   cur_conf,
                                                           1.0,
                                                           planned_config_list[i][1],
                                                           planned_config_list[i][2],
                                                           0.0, M_PI/2, 0.0,
                                                           0.83);
                    }
                    else if(k==2){ // place goal config
                        g_conf = solver->getGoalConfigs(   cur_conf,
                                                           planned_config_list[i][0],
                                                           planned_config_list[i][1],
                                                           planned_config_list[i][2],
                                                           0.0, M_PI/2, 0.0,
                                                           0.43);
                    }
                    // Fail to solve the inverse kinematic of the goal pose
                    if(g_conf[0]==0 && g_conf[1]==0 && g_conf[2]==0 && g_conf[3]==0 && g_conf[4]==0 && g_conf[5]==0){
                        Remaining_attempts_for_IK--;
                        ROS_WARN_STREAM("[Main - IK] fail to solve IK... (remaining attempts: "<<Remaining_attempts_for_IK<<")");
                        continue;
                    }else{
                        ROS_INFO_STREAM("[Main - IK] Succeed to find the goal configuration.");
                    }
                    ROS_INFO_STREAM("[Main - Planning] \n"
                                    << "# Start configuration: ["<<cur_conf[0]<<", "<<cur_conf[1]<<", "<<cur_conf[2]<<", "<<cur_conf[3]<<", "<<cur_conf[4]<<", "<<cur_conf[5]<<"] \n"
                                    << "# Goal  configuration: ["<<g_conf[0]<<", "<<g_conf[1]<<", "<<g_conf[2]<<", "<<g_conf[3]<<", "<<g_conf[4]<<", "<<g_conf[5]<<"]");
                    bool planning_result; // PLANNING
                    if(strcmp(argv[1],"sbmp")==0){
                        ROS_INFO("[Main - Planning] < Start sbmp planning >");
                        planning_result = sbmp->solve(cur_conf, g_conf, time_limit, elapsed_time);
                    }
                    else if(strcmp(argv[1],"csbmp")==0){
                        ROS_INFO("[Main - Planning] < Start csbmp planning >");
                        planning_result = sbmp->solve(cur_conf, g_conf, time_limit, solver, constraints, elapsed_time);
                    }
                    else if(strcmp(argv[1],"obmp")==0){
                        ROS_INFO("[Main - Planning] < Start obmp planning >");
                        planning_result = obmp->solve(cur_conf, g_conf, time_limit, collision_object_id, elapsed_time, solver, constraints, true);
                    }
                    ROS_INFO_STREAM("[Main - Planning] planning_result: "<<planning_result);
                    if(planning_result) {
                        ROS_INFO_STREAM("[Main - Planning] Success to find path in: "<<elapsed_time);
                        // for debugging and logging the result
                        Log_planning_time[Log_idx] = elapsed_time;
                        Log_average_planning_time += elapsed_time;
                        Log_idx++;
                        std::stringstream ss;
                        ss << std::fixed  << std::setprecision(print_dec_point) << "\n[Log - Used_times]: ";
                        for(uint q = 0; q<Log_idx; q++){
                            if((q+1)%4==0){
                                ss << Log_planning_time[q]<<"| ";
                            }else{
                                ss << Log_planning_time[q]<<", ";
                            }
                        }
                        ss << "\n[Log - Avg_time]: "<<Log_average_planning_time/(Log_idx) << " seconds";
                        ROS_INFO_STREAM(ss.str());
                        break;
                    }
                    time_limit += 0.1;
                }
                // VISUALIZATION
                if(strcmp(argv[1],"sbmp")==0 || strcmp(argv[1],"csbmp")==0){
                    sbmp->pathVisualization(100, 0.02);
                }
                else if(strcmp(argv[1],"obmp")==0){
                    obmp->pathVisualization(0.02); // N_interpolation is fixed to 101.
                }
                // Move to the next step.
                for(uint j=0; j<num_dof; j++){
                    cur_conf[j] = g_conf[j];
                }

                ros::Duration(0.1).sleep(); // Pause for a moment for visualization.
            }
            // [4] Detach the box from the robot's end-effector.
            scene->detachAttachedCollisionObject(collision_object_id);

            // [5] Generate the box at the goal position.
            scene->updateCollisionObject(collision_object_id, planned_config_list[i][0], planned_config_list[i][1], planned_config_list[i][2], 0, 0, 0);

            ROS_INFO_STREAM("[Main - PP] Done.\n");
        }
    }

    ROS_INFO("****************** The total task has been done. ******************");
    return 0;
}
