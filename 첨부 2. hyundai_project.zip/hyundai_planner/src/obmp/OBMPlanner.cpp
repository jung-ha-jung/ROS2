/* Author: Mincheul Kang */

#include <string.h>

#include <hyundai_planner/obmp/OBMPlanner.h>
#include <hyundai_planner/obmp/PathOptimizer.h>

#include <moveit/robot_state/conversions.h>
#include <moveit/collision_distance_field/collision_world_hybrid.h>
#include <moveit/collision_distance_field/collision_detector_allocator_hybrid.h>

#include <hyundai_planner/Scene.h>

void insertRobotStateToPath(const moveit::core::RobotState& state, const std::string& group, Eigen::MatrixXd::RowXpr jointArray){
    auto jointModelGroup = state.getJointModelGroup(group);
    int jointIdx = 0;
    for(auto jointModel : jointModelGroup->getActiveJointModels()){
        jointArray[jointIdx++] = state.getVariablePosition(jointModel->getFirstVariableIndex());
    }
}

OBMPlanner::OBMPlanner(const std::string &planning_group, planning_scene::PlanningScenePtr& planning_scene, ScenePtr& scene){
    planning_scene_ = planning_scene;
    planning_group_ = planning_group;
    scene_ = scene;

    robot_model_loader::RobotModelLoader robot_model_loader("robot_description");
    robot_model_ = robot_model_loader.getModel();
    robot_state::RobotStatePtr robot_state(new robot_state::RobotState(robot_model_));
    joint_model_group_ = robot_state->getJointModelGroup(planning_group);
    std::vector<std::string> indices = joint_model_group_->getActiveJointModelNames();
    num_dof_ = joint_model_group_->getVariableCount();

    collision_detection::CollisionDetectorAllocatorPtr hybrid_cd(collision_detection::CollisionDetectorAllocatorHybrid::create());
    // create a writable planning scene
    planning_scene_->setActiveCollisionDetector(hybrid_cd, true);

    for (uint i = 0; i < num_dof_; i++) {
        joint_state_.name.push_back(indices[i]);
    }

    mpr_.group_name = planning_group_;
    mpr_.allowed_planning_time = 10.0;
    mpr_.num_planning_attempts = 5;

    //// workspace parameters
    mpr_.workspace_parameters.min_corner.x = mpr_.workspace_parameters.min_corner.y = -2.0;
    mpr_.workspace_parameters.min_corner.z = 0.0;
    mpr_.workspace_parameters.max_corner.x = mpr_.workspace_parameters.max_corner.y = 2.0;
    mpr_.workspace_parameters.max_corner.z = 4.0;
}

bool OBMPlanner::solve(const std::vector<double> &s_conf, const std::vector<double> &g_conf, const double planning_time,
                       const std::string& collision_object_id, double &elapsed_time,
                       KinematicsSolverPtr &ksolver, const std::vector<std::pair<double, double> > &constraints, bool use_constraints){
    // start configuration
    moveit_msgs::RobotState start_state_msg;
    if(collision_object_id.compare("")!=0){
        ROS_INFO("[OBMP] Attach object to the robot : %s", collision_object_id.c_str());
        moveit_msgs::AttachedCollisionObject attached_object;
        attached_object.link_name = "hyundai_flange";
        attached_object.object.header.frame_id = "hyundai_flange";
        attached_object.object.id = collision_object_id;
        attached_object.object.primitives.push_back(scene_->getPrimitive(collision_object_id));
        attached_object.object.primitive_poses.push_back(scene_->getPose());
        attached_object.object.operation = attached_object.object.ADD;
        start_state_msg.attached_collision_objects.push_back(attached_object);
    }
    joint_state_.position.clear();
    for (uint i = 0; i < num_dof_; i++) {
        joint_state_.position.push_back(s_conf[i]);
    }
    start_state_msg.joint_state = joint_state_;
    mpr_.start_state = start_state_msg;

    // goal configuration
    robot_state::RobotState goal_state(robot_model_);
    goal_state.setJointGroupPositions(joint_model_group_, g_conf);

    moveit_msgs::Constraints joint_goal = kinematic_constraints::constructGoalConstraints(goal_state, joint_model_group_);
    mpr_.goal_constraints.clear();
    mpr_.goal_constraints.push_back(joint_goal);

    //// try to solve!!
    ros::WallTime start_time = ros::WallTime::now();
    if(!planning_scene_){
        ROS_ERROR("Planning scene is nullptr");
        mpdr_.error_code.val = moveit_msgs::MoveItErrorCodes::FAILURE;
        planning_success_ = false;
        return false;
    }
    robot_state::RobotState start_state = planning_scene_->getCurrentState();
    robot_state::robotStateMsgToRobotState(planning_scene_->getTransforms(), start_state_msg, start_state);
    if(!start_state.satisfiesBounds()){
        ROS_ERROR("Start state violates bounds");
        mpdr_.error_code.val = moveit_msgs::MoveItErrorCodes::INVALID_ROBOT_STATE;
        planning_success_ = false;
        return false;
    }
    std::shared_ptr<Path> path = std::make_shared<Path>(planning_scene_->getRobotModel(), 3., .03, mpr_.group_name);
    insertRobotStateToPath(start_state, mpr_.group_name, path->getPointAt(0));
    if(!goal_state.satisfiesBounds()){
        ROS_ERROR("Goal state violates bounds");
        mpdr_.error_code.val = moveit_msgs::MoveItErrorCodes::INVALID_ROBOT_STATE;
        planning_success_ = false;
        return false;
    }
    insertRobotStateToPath(goal_state, mpr_.group_name, path->getPointAt(path->n_points - 1));
    auto active_joint_models = planning_scene_->getRobotModel()->getJointModelGroup(mpr_.group_name)->getActiveJointModels();
    for(int i = 0; i < active_joint_models.size(); i++){
        auto jointModel = active_joint_models[i];
        auto revolute = dynamic_cast<const moveit::core::RevoluteJointModel*>(jointModel);
        if(revolute != nullptr){
            if(revolute->isContinuous()){
                path->at(path->n_points-1, i) = path->at(0, i) + shortestAngularDistance(path->at(0, i), path->at(path->n_points-1, i));
            }
        }
    }

    path->setPathWithMinimumJerk();

    double curr_planning_time = planning_time;

    std::unique_ptr<PathOptimizer> optimizer;
    optimizer.reset(new PathOptimizer(path, planning_scene_, mpr_.group_name, start_state, ksolver, constraints, use_constraints));

    optimizer->initialize();
    if(!optimizer->isInitialized_){
        ROS_ERROR("Path optimizer initialization failed");
        mpdr_.error_code.val = moveit_msgs::MoveItErrorCodes::PLANNING_FAILED;
        planning_success_ = false;
        return false;
    }

    ros::WallTime start_planning_time = ros::WallTime::now();
    optimizer->optimize(curr_planning_time);
    ros::WallTime end_planning_time = ros::WallTime::now();
    elapsed_time = (end_planning_time - start_planning_time).toSec();

    mpdr_.trajectory.resize(1);
    mpdr_.trajectory[0].joint_trajectory.joint_names = planning_scene_->getRobotModel()->getJointModelGroup(mpr_.group_name)->getActiveJointModelNames();
    mpdr_.trajectory[0].joint_trajectory.header = mpr_.start_state.joint_state.header;
    mpdr_.trajectory[0].joint_trajectory.points.resize(path->n_points);
    for(int i = 0; i < path->n_points; i++){
        mpdr_.trajectory[0].joint_trajectory.points[i].positions.resize(path->n_joints);
        for(int j = 0; j < path->n_joints; j++){
            mpdr_.trajectory[0].joint_trajectory.points[i].positions[j] = path->getPointAt(i)(j);
        }
        mpdr_.trajectory[0].joint_trajectory.points[i].time_from_start = ros::Duration(0);
    }
    mpdr_.error_code.val = moveit_msgs::MoveItErrorCodes::SUCCESS;
    mpdr_.processing_time.push_back((ros::WallTime::now() - start_time).toSec());

    if(not optimizer->isCollisionFree_){
        ROS_ERROR("Planning fails");
        mpdr_.error_code.val = moveit_msgs::MoveItErrorCodes::INVALID_MOTION_PLAN;
        planning_success_ = false;
        return planning_success_;
    }

    kinematic_constraints::JointConstraint jointConstraint(planning_scene_->getRobotModel());
    robot_state::RobotState at_goal_state(start_state);
    at_goal_state.setVariablePositions(mpdr_.trajectory[0].joint_trajectory.joint_names, mpdr_.trajectory[0].joint_trajectory.points.back().positions);

    bool satisfy_constraints = true;
    for(auto constraint : mpr_.goal_constraints[0].joint_constraints){
        satisfy_constraints = satisfy_constraints and jointConstraint.configure(constraint) and jointConstraint.decide(at_goal_state).satisfied;
        if(!satisfy_constraints){
            ROS_ERROR("Constraints are violated at the goal state");
            mpdr_.error_code.val = moveit_msgs::MoveItErrorCodes::GOAL_CONSTRAINTS_VIOLATED;
            planning_success_ = false;
            return planning_success_;
        }
    }
    planning_success_ = true;
    return planning_success_;
}

void OBMPlanner::pathVisualization(float dip_dt){
    ros::NodeHandle node_handle("~");
    ros::Publisher joint_pub = node_handle.advertise<sensor_msgs::JointState>("/joint_states", 1000);
    sensor_msgs::JointState joint_state;

    if(planning_success_){
        ros::Publisher display_pub = node_handle.advertise<moveit_msgs::DisplayTrajectory>("/move_group/display_planned_path", 1, true);
        moveit_msgs::DisplayTrajectory display_trajectory;
        moveit_msgs::RobotTrajectory robot_traj;
        robot_traj.joint_trajectory = mpdr_.trajectory[0].joint_trajectory;
        display_trajectory.trajectory.push_back(robot_traj);
        display_pub.publish(display_trajectory);
        ros::Duration(0.001).sleep();

        // Display Trajectory -- Publish Joint_states --
        for(uint i=0; i<mpdr_.trajectory[0].joint_trajectory.points.size(); i++){
            joint_state.header.stamp = ros::Time::now();
            joint_state.name.resize(6);
            joint_state.name[0] = "hyundai_joint1";
            joint_state.name[1] = "hyundai_joint2";
            joint_state.name[2] = "hyundai_joint3";
            joint_state.name[3] = "hyundai_joint4";
            joint_state.name[4] = "hyundai_joint5";
            joint_state.name[5] = "hyundai_joint6";
            joint_state.position.resize(6);
            joint_state.position[0] = mpdr_.trajectory[0].joint_trajectory.points[i].positions[0];
            joint_state.position[1] = mpdr_.trajectory[0].joint_trajectory.points[i].positions[1];
            joint_state.position[2] = mpdr_.trajectory[0].joint_trajectory.points[i].positions[2];
            joint_state.position[3] = mpdr_.trajectory[0].joint_trajectory.points[i].positions[3];
            joint_state.position[4] = mpdr_.trajectory[0].joint_trajectory.points[i].positions[4];
            joint_state.position[5] = mpdr_.trajectory[0].joint_trajectory.points[i].positions[5];
            joint_pub.publish(joint_state);
            ros::Duration(dip_dt).sleep();
        }
    }
}
