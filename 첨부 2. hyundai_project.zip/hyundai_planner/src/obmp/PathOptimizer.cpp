#include "hyundai_planner/obmp/PathOptimizer.h"

PathOptimizer::PathOptimizer(std::shared_ptr<Path> &path, const planning_scene::PlanningSceneConstPtr &planningScene, const std::string &group, const moveit::core::RobotState &robotState, KinematicsSolverPtr &ksolver, const std::vector<std::pair<double, double> > &constraints, bool use_constraints)
        : path_(path)
        , group_(group)
        , groupPath_(*path, group)
        , robotModel_(planningScene->getRobotModel())
        , planningScene_(planningScene)
        , currState_(robotState)
        , startState_(robotState)
        , isInitialized_(false)
        , ksolver_(ksolver)
        , constraints_(constraints)
        , use_constraints_(use_constraints)
{
    double resol = 0.5;
    double sizeX = 5.;
    double sizeY = 5.;
    double sizeZ = 7.;

    colliWorld_ = std::make_shared<collision_detection::CollisionWorldHybrid>((const collision_detection::WorldPtr &)planningScene->getWorld(), Eigen::Vector3d(sizeX, sizeY, sizeZ), Eigen::Vector3d(0, 0, 2.5),
                                                                              false, resol);
    colliRobot_ = std::make_shared<collision_detection::CollisionRobotHybrid>(robotModel_, std::map<std::string, std::vector<collision_detection::CollisionSphere> >(), sizeX, sizeY, sizeX, false, resol);

    if(!colliWorld_ || !colliRobot_){
        ROS_ERROR("Collision world or collision robot are not initialized!");
        return;
    }

    n_plannablePoints_ = groupPath_.getNumPlannablePoints();
    n_points_ = groupPath_.n_points;
    n_joints_ = groupPath_.n_joints;
    plannableStart_ = groupPath_.startIdx_;
    plannableEnd_ = groupPath_.endIdx_;

    collision_detection::CollisionRequest request;
    collision_detection::CollisionResult result;
    request.group_name = group_;
    colliWorld_->getCollisionGradients(request, result, *colliRobot_->getCollisionRobotDistanceField().get(), currState_, &planningScene_->getAllowedCollisionMatrix(), groupStateRepresentation_);

    n_colliPoints_ = 0;
    for(int i = 0; i < groupStateRepresentation_->gradients_.size(); i++){
        n_colliPoints_ += groupStateRepresentation_->gradients_[i].gradients.size();
    }

    jointSmoothCost_.reserve(n_joints_);
    double maxCostScale = 0;
    jointModelGroup_ = robotModel_->getJointModelGroup(group_);
    auto activeJointModels = jointModelGroup_->getActiveJointModels();
    for(int i = 0; i < activeJointModels.size(); i++){
        std::vector<double> dJointSmooth(3);
        dJointSmooth[0] = SMOOTH_VEL;
        dJointSmooth[1] = SMOOTH_ACC;
        dJointSmooth[2] = SMOOTH_JERK;
        jointSmoothCost_.emplace_back(groupPath_, dJointSmooth, RIDGE);
        double scale = jointSmoothCost_[i].quadraticCostInv_.maxCoeff();
        if(maxCostScale < scale)
            maxCostScale = scale;
    }
    for(int i = 0; i < n_joints_; i++){
        jointSmoothCost_[i].scale(maxCostScale);
    }


    std::map<std::string, std::string> fixedLinkResol;
    for(int i = 0; i < n_joints_; i++){
        jointNames_.push_back(activeJointModels[i]->getName());

        if(activeJointModels[i] != robotModel_->getRootJoint()){
            bool found = false;
            const moveit::core::JointModel* parent = nullptr;
            while(!found){
                if(parent == nullptr){
                    if(activeJointModels[i]->getParentLinkModel() == nullptr){
                        ROS_ERROR_STREAM(activeJointModels[i]->getName() << " has nullptr parent");
                        break;
                    }
                    else if(activeJointModels[i]->getParentLinkModel()->getParentJointModel() == nullptr){
                        ROS_ERROR_STREAM(activeJointModels[i]->getName() << " has nullptr parent");
                        break;
                    }
                    parent = activeJointModels[i]->getParentLinkModel()->getParentJointModel();
                }
                else{
                    if(parent == robotModel_->getRootJoint())
                        found = true;
                    else
                        parent = parent->getParentLinkModel()->getParentJointModel();
                }
                jointParent_[activeJointModels[i]->getName()][parent->getName()] = true;
            }
        }
        fixedLinkResol[jointNames_[i]] = jointNames_[i];
    }

    for(int i = 0; i < jointModelGroup_->getFixedJointModels().size(); i++){
        auto jointModel = jointModelGroup_->getFixedJointModels()[i];
        if(!jointModel->getParentLinkModel())
            continue;
        fixedLinkResol[jointModel->getName()] = jointModel->getParentLinkModel()->getParentJointModel()->getName();
    }

    for(int i = 0; i < jointModelGroup_->getUpdatedLinkModels().size(); i++){
        if(fixedLinkResol.find(jointModelGroup_->getUpdatedLinkModels()[i]->getParentJointModel()->getName()) == fixedLinkResol.end()){
            const moveit::core::JointModel* parent = nullptr;
            bool found = false;

            while(!found){
                if(parent == nullptr)
                    parent = jointModelGroup_->getUpdatedLinkModels()[i]->getParentJointModel();
                else{
                    parent = parent->getParentLinkModel()->getParentJointModel();
                    for(int j = 0; j < jointNames_.size(); j++){
                        if(parent->getName() == jointNames_[j])
                            found = true;

                    }
                }
            }
            fixedLinkResol[jointModelGroup_->getUpdatedLinkModels()[i]->getParentJointModel()->getName()] = parent->getName();
        }
    }

    colliJointNames_.resize(n_points_, std::vector<std::string>(n_colliPoints_));
    for(int i = plannableStart_; i <= plannableEnd_; i++){
        int ii = 0;
        for(int j = 0; j < groupStateRepresentation_->gradients_.size(); j++){
            auto info = groupStateRepresentation_->gradients_[j];
            for(int k = 0; k < info.sphere_locations.size(); k++){
                if(fixedLinkResol.find(info.joint_name) != fixedLinkResol.end())
                    colliJointNames_[i][ii] = fixedLinkResol[info.joint_name];
                ii++;
            }
        }
    }

    initialize();
}

void PathOptimizer::initialize(){
    isInitialized_ = false;

    smoothIncrement_ = Eigen::MatrixXd::Zero(n_plannablePoints_, n_joints_);
    collisionIncrement_ = Eigen::MatrixXd::Zero(n_plannablePoints_, n_joints_);
    constraintIncrement_ = Eigen::MatrixXd::Zero(n_plannablePoints_, n_joints_);
    costIncrement_ = Eigen::MatrixXd::Zero(n_plannablePoints_, n_joints_);
    dSmoothness_ = Eigen::VectorXd::Zero(n_points_);
    jacobian_ = Eigen::MatrixXd::Zero(3, n_joints_);
    jacobianInv_ = Eigen::MatrixXd::Zero(n_joints_, 3);
    jacoJacoTrans_ = Eigen::MatrixXd::Zero(3, 3);

    bestGroupPath_ = groupPath_.path_;

    colliPose_.resize(n_points_, EigenSTL::vector_Vector3d(n_colliPoints_));
    colliVel_.resize(n_points_, EigenSTL::vector_Vector3d(n_colliPoints_));
    colliAcc_.resize(n_points_, EigenSTL::vector_Vector3d(n_colliPoints_));

    jointAxes_.resize(n_points_, EigenSTL::vector_Vector3d(n_joints_));
    jointPositions_.resize(n_points_, EigenSTL::vector_Vector3d(n_joints_));

    colliPotential_.resize(n_points_, std::vector<double>(n_colliPoints_));
    colliSpeed_.resize(n_points_, std::vector<double>(n_colliPoints_));
    colliPotentialGradient_.resize(n_points_, EigenSTL::vector_Vector3d(n_colliPoints_));

    colliFreeIteration_ = 0;
    isCollisionFree_ = false;
    colliStates_.resize(n_points_);
    colliPoints_.resize(n_points_, std::vector<int>(n_colliPoints_));

    KDL::JntArray q(n_joints_);
    KDL::Frame p;

    if(use_constraints_){
        Eigen::MatrixXd::RowXpr startPoint = groupPath_.getPointAt(0);
        for(int k = 0; k < n_joints_; k++){
            q(k) = startPoint[k];
        }
        ksolver_->fkSolver(q, p);
        updateConstraints(p);
    }
    constraints_state_ = true;
    isInitialized_ = true;
}

bool PathOptimizer::optimize(double timeLimit) {
    ros::WallTime start_time = ros::WallTime::now();

    bool needBreak = false;

    for(iteration_ = 0; iteration_ < MAX_ITER; iteration_++){
        calculateForwardKinematics();

        double colliCost = 0;
        for(int i = plannableStart_; i <= plannableEnd_; i++){
            double colliCostAtPoint = 0;
            for(int j = 0; j < n_colliPoints_; j++){
                colliCostAtPoint += colliPotential_[i][j] * colliSpeed_[i][j];
            }
            colliCost += colliCostAtPoint;
        }
        colliCost *= WEIGHT_COLLISION_COST;

        double smoothCost = 0;
        for(int i = 0; i < n_joints_; i++){
            smoothCost += jointSmoothCost_[i].getCost(groupPath_.getJointsAt(i));
        }
        smoothCost *= WEIGHT_SMOOTH_COST;

        double totalCost = colliCost + smoothCost;

        if (iteration_ == 0 || totalCost < bestCost_){
            bestGroupPath_ = groupPath_.path_;
            bestCost_ = totalCost;
        }

        for(int i = 0; i < n_joints_; i++){
            Eigen::MatrixXd::ColXpr joints = groupPath_.getJointsAt(i);
            dSmoothness_ = jointSmoothCost_[i].quadraticFullCost_ *  (2. * joints);
            smoothIncrement_.col(i) = -dSmoothness_.segment(groupPath_.startIdx_, n_plannablePoints_);
        }

        collisionIncrement_.setZero();
        int start = int(double(random())/double(RAND_MAX) * (plannableEnd_ - plannableStart_) + plannableStart_);
        start = start < plannableStart_ ? plannableStart_ : start;
        start = start > plannableEnd_ ? plannableEnd_ : start;
        int end = start;
        for(int i = start; i <= end; i++){
            for(int j = 0; j < n_colliPoints_; j++){
                double potential = colliPotential_[i][j];
                if(potential < SMALL)
                    continue;
                Eigen::Vector3d gradient = -colliPotentialGradient_[i][j];
                double speed = colliSpeed_[i][j];

                Eigen::Vector3d velNormal = colliVel_[i][j] / speed;
                Eigen::Matrix3d ortho = Eigen::Matrix3d::Identity() - (velNormal * velNormal.transpose());
                Eigen::Vector3d curvature = (ortho * colliAcc_[i][j]) / (speed * speed);
                Eigen::Vector3d gradientInCartesian = speed * (ortho * gradient - potential * curvature);

                calculateJacobianAt(i, colliPose_[i][j], colliJointNames_[i][j], jacobian_);
                collisionIncrement_.row(i - plannableStart_).transpose() -= jacobian_.transpose() * gradientInCartesian;
            }
        }

        if(use_constraints_){
            computeConstraintCost();

            for (int i = 0; i < n_joints_; i++)
            {
                Eigen::MatrixXd gt = (WEIGHT_SMOOTH_COST * smoothIncrement_.col(i) +
                        WEIGHT_COLLISION_COST * collisionIncrement_.col(i));
                Eigen::MatrixXd m_const = constraintIncrement_.col(i);
                Eigen::MatrixXd offset = jointSmoothCost_[i].quadraticCostInv_ * m_const *
                                         (m_const.transpose()*jointSmoothCost_[i].quadraticCostInv_*m_const).inverse();

                costIncrement_.col(i) =
                        LEARNING_RATE * (jointSmoothCost_[i].quadraticCostInv_ * gt)
                        -LEARNING_RATE * (offset * m_const.transpose() * jointSmoothCost_[i].quadraticCostInv_ * gt)
                        +constraints_value_ * offset;
            }
        }
        else{
            for(int i = 0; i < n_joints_; i++){
                costIncrement_.col(i) = LEARNING_RATE * (jointSmoothCost_[i].quadraticCostInv_ * (WEIGHT_SMOOTH_COST * smoothIncrement_.col(i) + WEIGHT_COLLISION_COST * collisionIncrement_.col(i)));
            }
        }

        for(int i = 0; i < jointModelGroup_->getActiveJointModels().size(); i++){
            double scale = 1.;
            double max_scale = JOINT_UPDATE_LIMIT / fabs(costIncrement_.col(i).maxCoeff());
            double min_scale = JOINT_UPDATE_LIMIT / fabs(costIncrement_.col(i).minCoeff());
            if(max_scale < scale)
                scale = max_scale;
            if(min_scale < scale)
                scale = min_scale;
            groupPath_.getPlannablePath().col(i) += scale * costIncrement_.col(i);
        }

        fixJointLimitViolation();
        path_->update(groupPath_);

        if(iteration_ % MESH_TO_MESH_COLLISION_CHECK_TERM == 0){
            moveit_msgs::RobotTrajectory robotTrajectory;
            robotTrajectory.joint_trajectory.joint_names = jointNames_;
            for(int i = 0; i < groupPath_.n_points; i++){
                trajectory_msgs::JointTrajectoryPoint point;
                for(int j = 0; j < groupPath_.n_joints; j++){
                    point.positions.push_back(bestGroupPath_(i, j));
                }
                robotTrajectory.joint_trajectory.points.push_back(point);
            }
            moveit_msgs::RobotState startState;
            moveit::core::robotStateToRobotStateMsg(startState_, startState);

            if(constraints_state_ && planningScene_->isPathValid(startState, robotTrajectory, group_)){
                n_colliFreeIter_ = 0;
                isCollisionFree_ = true;
                iteration_++;
                needBreak = true;
            }
        }

        if (colliCost < 0.1)
        {
            n_colliFreeIter_ = 200;
            isCollisionFree_ = true;
            iteration_++;
            needBreak = true;
        }

        if((ros::WallTime::now() - start_time).toSec() > timeLimit){
            ROS_INFO("Time limit violation");
            break;
        }

        if(needBreak){
            colliFreeIteration_++;
            if(n_colliFreeIter_ == 0 || colliFreeIteration_ > n_colliFreeIter_)
                break;
        }
    }

    groupPath_.path_ = bestGroupPath_;
    path_->update(groupPath_);

    return isCollisionFree_;
}

bool PathOptimizer::solve(const moveit_msgs::MotionPlanRequest& req, double timeLimit,
                          moveit_msgs::MotionPlanDetailedResponse& res) {

    if(!planningScene_){
        ROS_ERROR("Planning scene is nullptr");
        res.error_code.val = moveit_msgs::MoveItErrorCodes::FAILURE;
        return false;
    }
    if(!startState_.satisfiesBounds()){
        ROS_ERROR("Start state violates bounds");
        res.error_code.val = moveit_msgs::MoveItErrorCodes::INVALID_ROBOT_STATE;
        return false;
    }
    robot_state::RobotState goalState(startState_);
    for(int i = 0; i < req.goal_constraints[0].joint_constraints.size(); i++){
        auto jointConstraint = req.goal_constraints[0].joint_constraints[i];
        goalState.setVariablePosition(jointConstraint.joint_name, jointConstraint.position);
    }
    if(!goalState.satisfiesBounds()){
        ROS_ERROR("Goal state violates bounds");
        res.error_code.val = moveit_msgs::MoveItErrorCodes::INVALID_ROBOT_STATE;
        return false;
    }


}

double PathOptimizer::calculatePotential(double distance, double radius, double clearence) {
    double dist = distance - radius;
    double potential = 0;

    if(dist >= clearence){
        potential = 0;
    }
    else if(dist >= 0){
        potential = 0.5 * ((dist - clearence) * clearence) * (dist - clearence);
    }
    else{
        potential = -dist + 0.5 * clearence;
    }
    return potential;
}

void PathOptimizer::calculateJacobianAt(int point, Eigen::Vector3d &colliPose, std::string &jointName, Eigen::MatrixXd& jaco) {
    for(int i = 0; i < n_joints_; i++){
        if(isParent(jointName, jointNames_[i])){
            Eigen::Vector3d col = jointAxes_[point][i].cross(Eigen::Vector3d(colliPose[0], colliPose[1], colliPose[2]) - jointPositions_[point][i]);
            jaco.col(i)[0] = col.x();
            jaco.col(i)[1] = col.y();
            jaco.col(i)[2] = col.z();
        }
        else{
            jaco.col(i)[0] = 0;
            jaco.col(i)[1] = 0;
            jaco.col(i)[2] = 0;
        }
    }
}

void PathOptimizer::setCurrentStateAs(int point, Path &groupPath) {
    const Eigen::MatrixXd::RowXpr& pathPoint = groupPath.getPointAt(point);

    std::vector<double> jointStates;
    jointStates.reserve(groupPath.n_joints);
    for(int i = 0; i < groupPath.n_joints; i++){
        jointStates.emplace_back(pathPoint(0, i));
    }

    currState_.setJointGroupPositions(group_, jointStates);
    currState_.update();
}

void PathOptimizer::calculateForwardKinematics() {
    double dt = 1. / groupPath_.discretization_;
    int start = (iteration_ == 0) ? 0 : plannableStart_;
    int end = (iteration_ == 0) ? n_points_-1 : plannableEnd_;

    isCollisionFree_ = true;
    for(int i = start; i <= end; ++i){
        collision_detection::CollisionRequest request;
        collision_detection::CollisionResult result;
        request.group_name = group_;
        setCurrentStateAs(i, groupPath_);

        colliWorld_->getCollisionGradients(request, result, *colliRobot_->getCollisionRobotDistanceField().get(), currState_,
                                           nullptr, groupStateRepresentation_);
        for(int j = 0; j < n_joints_; j++){
            const moveit::core::JointModel* jointModel = currState_.getJointModel(jointNames_[j]);
            auto revolute = dynamic_cast<const moveit::core::RevoluteJointModel*>(jointModel);
            auto prismatic = dynamic_cast<const moveit::core::PrismaticJointModel*>(jointModel);

            std::string parentName = jointModel->getParentLinkModel()->getName();
            std::string childName = jointModel->getChildLinkModel()->getName();
            auto transform = currState_.getGlobalLinkTransform(parentName) * (robotModel_->getLinkModel(childName)->getJointOriginTransform() * currState_.getJointTransform(jointModel));
            Eigen::Vector3d axis = Eigen::Vector3d::Identity();
            if(revolute != nullptr)
                axis = revolute->getAxis();
            else if(prismatic != nullptr)
                axis = prismatic->getAxis();
            axis = transform * axis;
            jointAxes_[i][j] = axis;
            jointPositions_[i][j] = transform.translation();
        }

        colliStates_[i] = false;

        int j = 0;
        for(int k = 0; k < groupStateRepresentation_->gradients_.size(); k++){
            collision_detection::GradientInfo& info = groupStateRepresentation_->gradients_[k];
            for(int l = 0; l < info.sphere_locations.size(); l++){
                colliPose_[i][j][0] = info.sphere_locations[l].x();
                colliPose_[i][j][1] = info.sphere_locations[l].y();
                colliPose_[i][j][2] = info.sphere_locations[l].z();

                colliPotential_[i][j] = calculatePotential(info.distances[l], info.sphere_radii[l], MIN_CLEARENCE);
                colliPotentialGradient_[i][j][0] = info.gradients[l].x();
                colliPotentialGradient_[i][j][1] = info.gradients[l].y();
                colliPotentialGradient_[i][j][2] = info.gradients[l].z();
                colliPoints_[i][j] = (info.distances[l] < 2*info.sphere_radii[l]);
                if(colliPoints_[i][j]){
                    colliStates_[i] = true;
                    isCollisionFree_ = false;
                }
                j++;
            }
        }
    }

    for(int i = plannableStart_; i <= plannableEnd_; i++){
        for(int j = 0; j < n_colliPoints_; j++){
            colliVel_[i][j] = Eigen::Vector3d(0, 0, 0);
            colliAcc_[i][j] = Eigen::Vector3d(0, 0, 0);
            for(int k = -DIFF_LEN/2; k <= DIFF_LEN/2; k++){
                colliVel_[i][j] += dt * DIFF_COEFF[0][k + DIFF_LEN/2] * colliPose_[i + k][j];
                colliAcc_[i][j] += dt  * dt * DIFF_COEFF[1][k + DIFF_LEN/2] * colliPose_[i + k][j];
            }
            colliSpeed_[i][j] = colliVel_[i][j].norm();
        }
    }
}

void PathOptimizer::fixJointLimitViolation(){
    auto activeJointModels = jointModelGroup_->getActiveJointModels();
    for(int i = 0; i < activeJointModels.size(); i++){
        auto jointModel = activeJointModels[i];
        if(jointModel->getType() == moveit::core::JointModel::REVOLUTE){
            auto revolute = dynamic_cast<const moveit::core::RevoluteJointModel*>(jointModel);
            if(revolute->isContinuous())
                continue;
        }

        auto bounds = jointModel->getVariableBounds();
        double max = -DBL_MAX;
        double min = DBL_MAX;
        for(auto it = bounds.begin(); it != bounds.end(); it++){
            if(it->min_position_ < min)
                min = it->min_position_;
            if(it->max_position_ > max)
                max = it->max_position_;
        }

        int c = 0;
        bool isViolated = false;
        do{
            double violationThreshold = 1e-6;
            double maxViolation = 0;
            int maxViolationIdx = 0;
            isViolated = false;
            for(int j = plannableStart_; j <= plannableEnd_; j++){
                double violation = 0;
                if(groupPath_.at(j, i) > max){
                    violation = max - groupPath_.at(j, i);
                }
                else if(groupPath_.at(j, i) < min){
                    violation = min - groupPath_.at(j, i);
                }
                if(fabs(violation) > violationThreshold){
                    violationThreshold = fabs(violation);
                    maxViolation = violation;
                    maxViolationIdx = j;
                    isViolated = true;
                }
            }
            if(isViolated){
                int plannableIdx = maxViolationIdx - plannableStart_;

                double multiplier = maxViolation / jointSmoothCost_[i].quadraticCostInv_(plannableIdx, plannableIdx);
                groupPath_.getPlannableJointAt(i) += multiplier * jointSmoothCost_[i].quadraticCostInv_.col(plannableIdx);
            }
            if(++c > 10) break;
        }while(isViolated);
    }
}

std::vector<double> PathOptimizer::getEEPose(KDL::Frame &p){
    std::vector<double> eePose;
    KDL::Frame baseFrame_;

    KDL::Frame targetFrame = baseFrame_.Inverse() * p;

    eePose.push_back(p.p.data[0]);
    eePose.push_back(p.p.data[1]);
    eePose.push_back(p.p.data[2]);
    double roll, pitch, yaw;
    p.M.GetRPY(roll, pitch, yaw);

    for(int i = 0; i < 9; i++){
        if(std::abs(targetFrame.M.data[i]) < 1e-5){
            targetFrame.M.data[i] = 0.0;
        }
        if(targetFrame.M.data[i] > 1){
            targetFrame.M.data[i] = 1;

        }
        if(targetFrame.M.data[i] < -1){
            targetFrame.M.data[i] = -1;
        }
    }

    eePose.push_back(atan2(targetFrame.M.data[7], targetFrame.M.data[8]));
    eePose.push_back(-asin(targetFrame.M.data[6]));
    eePose.push_back(atan2(targetFrame.M.data[3], targetFrame.M.data[0]) );

    return eePose;
}

void PathOptimizer::updateConstraints(KDL::Frame &p){
    referPose_ = getEEPose(p);

    update_constraints_.clear();
    for(auto i = 0; i < constraints_.size(); i++){
        std::pair<double, double> c = constraints_[i];
        if(c.first == 0 && c.second == 0){
            update_constraints_.push_back(c);
            continue;
        }
        double lower, upper;
        lower = c.first + referPose_[i];
        if(lower < -M_PI)
            lower += 2*M_PI;
        upper = c.second + referPose_[i];
        if(upper > M_PI)
            upper -= 2*M_PI;
        update_constraints_.push_back(std::make_pair(lower, upper));
    }
}

bool PathOptimizer::satisfyConstraints(KDL::Frame &p) {
    std::vector<double> eePose = getEEPose(p);

    for(auto i = 0; i < update_constraints_.size(); i++){
        std::pair<double, double> c = update_constraints_[i];
        if(c.first == 0 && c.second == 0){
            continue;
        }
        double v = eePose[i];
        if(c.first < c.second){
            if(c.first > v || c.second < v){
                return false;
            }
        }
        else{
            if(c.first < v || c.second > v){
                return false;
            }
        }
    }
    return true;
}

void PathOptimizer::computeConstraintCost(){
    double cost = 0.0;

    KDL::JntArray q(n_joints_);
    KDL::Frame p;
    KDL::Jacobian jac(n_joints_);
    Eigen::MatrixXd traj = groupPath_.path_;
    Eigen::VectorXd c;
    c.resize(n_joints_);
    constraints_state_ = true;
    for (int i = 0; i < n_plannablePoints_; i++) {
        for (int j = 0; j < n_joints_; j++) {
            q(j) = traj(i+6, j);
        }
        ksolver_->fkSolver(q, p);
        if(use_constraints_ && constraints_state_){
            if(!satisfyConstraints(p)){
                constraints_state_ = false;
            }
        }
        ksolver_->computeJacobian(q, jac);
        cost += computeConstraint(p, c);
        constraintIncrement_.row(i) = jac.data.transpose() * c;
    }

    constraints_value_ = cost/(double)n_plannablePoints_;
}

double PathOptimizer::computeConstraint(KDL::Frame &p, Eigen::VectorXd &vec) {
    std::vector<double> eePose = getEEPose(p);

    double cost = 0.0;
    for(auto i = 0; i < update_constraints_.size(); i++){
        std::pair<double, double> c = update_constraints_[i];
        if(c.first == 0 && c.second == 0){
            vec(i) = 0;
            continue;
        }
        double v = eePose[i]-referPose_[i];
        double abs_v = std::abs(v);
        if(abs_v > M_PI){
            abs_v = 2*M_PI - abs_v;
            v = referPose_[i]-eePose[i];
        }
        cost += abs_v;
        vec(i) = v;
    }
    return cost;
}

bool PathOptimizer::isCurrentTrajectorySatisfyConstraint()
{
    if(!use_constraints_){
        return true;
    }

    KDL::JntArray q(n_joints_);
    KDL::Frame p;

    for (int i = 0; i < n_plannablePoints_; i++) {
        for (int j = 0; j < n_joints_; j++) {
            q(j) = bestGroupPath_(i+6, j);
        }
        ksolver_->fkSolver(q, p);
        if(!satisfyConstraints(p)){
            return false;
        }
    }

    return true;
}