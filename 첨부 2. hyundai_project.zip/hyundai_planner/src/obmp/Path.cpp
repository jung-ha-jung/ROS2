#include "hyundai_planner/obmp/Path.h"

Path::Path(const moveit::core::RobotModelConstPtr &model, double duration, double discretization, const std::string &group)
: n_points((duration / discretization) + 1)
, discretization_(discretization)
, duration_(duration)
, startIdx_(1)
, endIdx_(n_points - 2){
    n_joints = model->getJointModelGroup(group)->getActiveJointModels().size();
    path_.resize(n_points, n_joints);
    path_ = Eigen::MatrixXd(n_points, n_joints);
}

Path::Path(const Path &original_path, const std::string &group)
: discretization_(original_path.discretization_){
    n_joints = original_path.n_joints;
    int start = (DIFF_LEN - 1) - original_path.startIdx_;
    int end = (DIFF_LEN - 1) - ((original_path.n_points - 1) - original_path.endIdx_);

    n_points = original_path.n_points + start + end;
    startIdx_ = DIFF_LEN - 1;
    endIdx_ = (n_points - 1) - (DIFF_LEN - 1);
    duration_ = (n_points - 1) * discretization_;
    path_.resize(n_points, n_joints);
    path_ = Eigen::MatrixXd(n_points, n_joints);

    for(int i = 0; i < n_points; i++){
        int point = i - start;
        if(point < 0)
            point = 0;
        if(point >= original_path.n_points)
            point = original_path.n_points - 1;
        for(int j = 0; j < n_joints; j++){
            at(i, j) = original_path.at(point, j);
        }
    }
}

void Path::update(const Path& path){
    int n_plannablePoints = endIdx_ - startIdx_ + 1;
    for(int i = 0; i < n_joints; i++){
        path_.block(startIdx_, i, n_plannablePoints, 1) = path.path_.block(path.startIdx_, i, n_plannablePoints, 1);
    }
}

void Path::setPathWithMinimumJerk() {
    double start = startIdx_ - 1;
    double end = endIdx_ + 1;

    double t[6];
    t[0] = 1;
    t[1] = (end - start) * discretization_;

    for(int i = 2; i < 6; i++){
        t[i] = t[i-1] * t[1];
    }

    std::vector<double[6]> coeff(n_joints);
    for(int i = 0; i < n_joints; i++){
        double x = at(start, i);
        double y = at(end, i);
        coeff[i][0] = x;
        coeff[i][1] = 0;
        coeff[i][2] = 0;
        coeff[i][3] = (-20 * x + 20 * y) / (2 * t[3]);
        coeff[i][4] = (30 * x - 30 * y) / (2 * t[4]);
        coeff[i][5] = (-12 * x + 12 * y) / (2 * t[5]);
    }

    for(int i = start + 1 ; i < end; i++){
        double k[6];
        k[0] = 1;
        k[1] = (i - start) * discretization_;
        for(int j = 2; j < 6; j++){
            k[j] = k[j-1] * k[1];
        }

        for(int j = 0; j < n_joints; j++){
            at(i, j) = 0;
            for(int l = 0; l < 6; l++){
                at(i, j) += k[l] * coeff[j][l];
            }
        }
    }
}