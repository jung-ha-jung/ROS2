#include "hyundai_planner/obmp/CostBase.h"

CostBase::CostBase(const Path &path, const std::vector<double> &dCost, double ridge) {
    int n_points = path.n_points;
    int n_plannablePoints = n_points - 2 * (DIFF_LEN - 1);
    Eigen::MatrixXd diff = Eigen::MatrixXd::Zero(n_points, n_points);
    quadraticFullCost_ = Eigen::MatrixXd::Zero(n_points, n_points);

    double t = 1.;
    for(int i = 0; i < dCost.size(); i++){
        t *= path.discretization_;
        diff = calculateDiff(n_points, i);
        quadraticFullCost_ += (dCost[i] * t) * (diff.transpose() * diff);
    }
    quadraticFullCost_ += Eigen::MatrixXd::Identity(n_points, n_points) * ridge;
    quadraticCost_ = quadraticFullCost_.block(DIFF_LEN-1, DIFF_LEN-1, n_plannablePoints, n_plannablePoints);
    quadraticCostInv_ = quadraticCost_.inverse();
}

Eigen::MatrixXd CostBase::calculateDiff(int size, int diffIdx) {
    Eigen::MatrixXd m = Eigen::MatrixXd::Zero(size, size);
    for(int i = 0; i < size; i++){
        for(int j = -DIFF_LEN/2; j <= DIFF_LEN/2; j++){
            int idx = i + j;
            if(idx < 0)
                continue;
            if(idx >= size)
                continue;
            m(i, idx) = DIFF_COEFF[diffIdx][j + DIFF_LEN/2];
        }
    }
    return m;
}