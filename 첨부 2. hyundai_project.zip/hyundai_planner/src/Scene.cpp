/* Author: Mincheul Kang */

#include <hyundai_planner/Scene.h>

Scene::Scene(planning_scene::PlanningScenePtr& planning_scene, std::string frameID){
    planning_scene_ = planning_scene;
    frameID_ = frameID;
}

moveit_msgs::CollisionObject Scene::addBox(std::string name,
                                           double x, double y, double z,
                                           double d_x, double d_y, double d_z,
                                           double roll, double pitch, double yaw){
    moveit_msgs::CollisionObject box;

    // Add the first table where the cube will originally be kept.
    box.id = name;
    box.header.frame_id = frameID_;

    /* Define the primitive and its dimensions. */
    box.primitives.resize(1);
    box.primitives[0].type = box.primitives[0].BOX;
    box.primitives[0].dimensions.resize(3);
    box.primitives[0].dimensions[0] = d_x;
    box.primitives[0].dimensions[1] = d_y;
    box.primitives[0].dimensions[2] = d_z;

    /* Define the pose of the box. */
    box.primitive_poses.resize(1);
    box.primitive_poses[0].position.x = x;
    box.primitive_poses[0].position.y = y;
    box.primitive_poses[0].position.z = z;

    tf::Quaternion q;
    q.setRPY(roll, pitch, yaw);

    box.primitive_poses[0].orientation.w = q.w();
    box.primitive_poses[0].orientation.x = q.x();
    box.primitive_poses[0].orientation.y = q.y();
    box.primitive_poses[0].orientation.z = q.z();

    box.operation = box.ADD;

    return box;
}

void Scene::removeBox(std::string name){
    moveit_msgs::CollisionObject box;

    box.id = name;
    box.header.frame_id = frameID_;

    box.operation = box.REMOVE;

    planning_scene_interface_.applyCollisionObject(box);
}

void Scene::addCollisionObjects(const std::string scene_num){
    std::vector<moveit_msgs::CollisionObject> collision_objects;
    std::string project_path = ros::package::getPath("hyundai_planner");
    std::string scene_path = project_path + "/include/hyundai_planner/scenes/scene" + scene_num + ".csv";
    std::ifstream infile(scene_path);
    if (!infile.is_open()){
        ROS_INFO("error: No scene selected...");
    }

    std::string line;
    uint num_of_boxes = 0;
    const int num_param = 10;
    while(getline(infile, line)){
        std::istringstream ss(line);
        std::string buf;
        std::string param[num_param];
        for (int i = 0; i < num_param; i++) {
            getline(ss, buf, ',');
            param[i] = buf;
        }
        collision_objects.push_back(addBox(param[0],
                                            stod(param[1]), stod(param[2]), stod(param[3]),
                                            stod(param[4]), stod(param[5]), stod(param[6]),
                                            stod(param[7]), stod(param[8]), stod(param[9])));
        if (boost::algorithm::contains(param[0], "box")){
            num_of_boxes++;
        }
    }
    infile.close();

    this->collision_objects.assign(collision_objects.begin(), collision_objects.begin() + num_of_boxes);

    auto object_colors = getColorObjects(collision_objects);

    planning_scene_interface_.applyCollisionObjects(collision_objects, object_colors);
}

std::vector<moveit_msgs::ObjectColor> Scene::getColorObjects(const std::vector<moveit_msgs::CollisionObject>& objects) {
    std::vector<moveit_msgs::ObjectColor> color_objects;
    moveit_msgs::ObjectColor object_color;
    double alpha = 1;

    for (auto &obj : objects){
        object_color.id = obj.id;
        if (boost::algorithm::contains(obj.id, "box")){
            object_color.color = getRGBA("GOLDEN_ROD", alpha);
        }
        else if (boost::algorithm::contains(obj.id, "floor")){
            object_color.color = getRGBA("GRAY", alpha);
        }
        else if (boost::algorithm::contains(obj.id, "table")){
            object_color.color = getRGBA("SILVER", alpha);
        }
        else if (boost::algorithm::contains(obj.id, "obs")){
            object_color.color = getRGBA("OLIVE", alpha);
        }
        else if (boost::algorithm::contains(obj.id, "wall")){
            object_color.color = getRGBA("SILVER", alpha);
        }
        else if (boost::algorithm::contains(obj.id, "ceiling")){
            object_color.color = getRGBA("SILVER", alpha);
        }
        color_objects.push_back(object_color);
    }

    return color_objects;
}

std_msgs::ColorRGBA Scene::getRGBA(const std::string& color, double alpha) {
    std_msgs::ColorRGBA cl;

    if (color == "BLACK"){cl.r = 0; cl.g = 0; cl.b = 0;}
    else if(color == "WHITE"){cl.r = 255; cl.g = 255; cl.b = 255;}
    else if(color == "RED"){cl.r = 255; cl.g = 0; cl.b = 0;}
    else if(color == "LIME"){cl.r = 0; cl.g = 255; cl.b = 0;}
    else if(color == "BLUE"){cl.r = 0; cl.g = 0; cl.b = 255;}
    else if(color == "YELLOW"){cl.r = 255; cl.g = 255; cl.b = 0;}
    else if(color == "CYAN"){cl.r = 0; cl.g = 255; cl.b = 255;}
    else if(color == "GRAY"){cl.r = 128; cl.g = 128; cl.b = 128;}
    else if(color == "DARK_SLATE_GRAY"){cl.r = 47; cl.g = 79; cl.b = 79;}
    else if(color == "BROWN"){cl.r = 165; cl.g = 42; cl.b = 42;}
    else if(color == "MAROON"){cl.r = 128; cl.g = 0; cl.b = 0;}
    else if(color == "OLIVE"){cl.r = 128; cl.g = 128; cl.b = 0;}
    else if(color == "NAVY"){cl.r = 0; cl.g = 0; cl.b = 128;}
    else if(color == "SILVER"){cl.r = 192; cl.g = 192; cl.b = 192;}
    else if(color == "GOLDEN_ROD"){cl.r = 218; cl.g = 165; cl.b = 32;}

    cl.r /= 255;
    cl.g /= 255;
    cl.b /= 255;

    cl.a = alpha;

    return cl;
}

void Scene::updateGlobalCollisionScene(){
    std::map<std::string, moveit_msgs::CollisionObject> collision_objects_map = planning_scene_interface_.getObjects();

    for(auto& kv : collision_objects_map){
        planning_scene_->processCollisionObjectMsg(kv.second);
    }
}

void Scene::removeCollisionObject(const std::string& object_id) {
    for(auto& obj : this->collision_objects){
        if (obj.id == object_id){
            obj.operation = obj.REMOVE;
            planning_scene_->processCollisionObjectMsg(obj);
            break;
        }
    }
}

void Scene::updateCollisionObject(const std::string& object_id,
                                  double x, double y, double z,
                                  double roll, double pitch, double yaw) {
    for(auto& obj : this->collision_objects){
        if (obj.id == object_id){
            obj.operation = obj.ADD;

            obj.primitive_poses[0].position.x = x;
            obj.primitive_poses[0].position.y = y;
            obj.primitive_poses[0].position.z = z;
            tf::Quaternion q;
            q.setRPY(roll, pitch, yaw);

            obj.primitive_poses[0].orientation.w = q.w();
            obj.primitive_poses[0].orientation.x = q.x();
            obj.primitive_poses[0].orientation.y = q.y();
            obj.primitive_poses[0].orientation.z = q.z();

            planning_scene_->processCollisionObjectMsg(obj);
            break;
        }
    }
}

std::vector<moveit_msgs::CollisionObject> Scene::getBox() {
    return this->collision_objects;
}

shape_msgs::SolidPrimitive Scene::getPrimitive(const std::string &object_id) {
    shape_msgs::SolidPrimitive primitive;
    primitive.type = primitive.BOX;
    primitive.dimensions.resize(3);
    for(auto& obj : this->collision_objects){
        if (obj.id == object_id){
            primitive.dimensions[0] = obj.primitives[0].dimensions[2];
            primitive.dimensions[1] = obj.primitives[0].dimensions[1];
            primitive.dimensions[2] = obj.primitives[0].dimensions[0];
        }
    }
    return primitive;
}
geometry_msgs::Pose Scene::getPose() {
    geometry_msgs::Pose pose;
    pose.position.x = 0.43;
    pose.orientation.w = 1.0;
    return pose;
}

moveit::planning_interface::PlanningSceneInterface Scene::getPlanningSceneInterface() {
    return this->planning_scene_interface_;
}


void Scene::addAttachedCollisionObject(const std::string& collision_object_id) {
    moveit_msgs::AttachedCollisionObject attached_object;
    attached_object.link_name = "hyundai_flange";
    attached_object.object.header.frame_id = "hyundai_flange";
    attached_object.object.id = collision_object_id;
    attached_object.object.primitives.push_back(this->getPrimitive(collision_object_id));
    attached_object.object.primitive_poses.push_back(this->getPose());
    attached_object.object.operation = attached_object.object.ADD;
    planning_scene_interface_.applyAttachedCollisionObject(attached_object);
    planning_scene_->processAttachedCollisionObjectMsg(attached_object);
}

void Scene::detachAttachedCollisionObject(const std::string& collision_object_id) {
    moveit_msgs::AttachedCollisionObject attached_object;
    attached_object.link_name = "hyundai_flange";
    attached_object.object.header.frame_id = "hyundai_flange";
    attached_object.object.id = collision_object_id;
    attached_object.object.operation = attached_object.object.REMOVE;
    planning_scene_interface_.applyAttachedCollisionObject(attached_object);
    planning_scene_->processAttachedCollisionObjectMsg(attached_object);
}