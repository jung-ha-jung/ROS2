/* Author: Hyeongyeol Ryu */

#include <ros/package.h>
#include "hyundai_planner/tp/TaskPlanner.h"

TaskPlanner::TaskPlanner(std::string soln_file_path) {
    this->soln_file_path = soln_file_path;
}

void TaskPlanner::ParseTask() {
    std::ifstream infile(this->soln_file_path);
    std::string line;
    const int num_param = 3;
    unsigned task_num = 0;

    if (!infile.is_open()){
        ROS_INFO("error: A solution file is not opened.");
    }

    getline(infile, line); // Skip the first line
    for (int i = 0; i < NUM_OF_BOXES * 2; i++) {
        getline(infile, line);
        line = line.substr(1, line.length() - 2); // Remove '(' and ')'
        std::istringstream ss(line);
        std::string buf;
        std::string param[num_param];
        for (int i = 0; i < num_param; i++) {
            getline(ss, buf, ' ');
            param[i] = buf;
        }
        auto task_tuple = std::make_tuple(param[0], param[1], param[2]); // example: [PICK, BOX5, S5]
        this->tasks.push_back(task_tuple);
        task_num++;
    }
    this->task_num = task_num;
    infile.close();
}

void TaskPlanner::ParseStartGoalConfig() {
    std::string parse_result_path = this->project_path + "/include/hyundai_planner/scenes/tp_parse_result.txt";
    std::ifstream infile(parse_result_path);
    std::string line;
    const int num_param = 7;

    while(getline(infile, line)){
        std::istringstream ss(line);
        std::string buf;
        std::string param[num_param];
        for (int i = 0; i < num_param; i++) {
            getline(ss, buf, ' ');
            param[i] = buf;
        }
        auto start_config = std::make_tuple(stod(param[1]), stod(param[2]), stod(param[3]));
        auto goal_config = std::make_tuple(stod(param[4]), stod(param[5]), stod(param[6]));
        auto task_config = std::make_tuple(param[0], start_config, goal_config);
        this->configs.push_back(task_config);
    }
    infile.close();
}

std::vector<std::tuple<std::string, std::string, std::string>> TaskPlanner::GetTasks() {
    return this->tasks;
}

std::vector<std::tuple<std::string, std::tuple<double, double, double>, std::tuple<double, double, double>>>
TaskPlanner::GetConfigs() {
    return this->configs;
}

void TaskPlanner::GenerateParsedFile() {
    std::string config_path = this->project_path + "/include/hyundai_planner/scenes/start_goal_config.csv";
    std::string parsed_file_path = this->project_path + "/include/hyundai_planner/scenes/tp_parse_result.txt";
    std::ifstream infile(config_path);
    std::ofstream outfile(parsed_file_path);
    std::string line;
    const int num_param = 7;
    const int num_primitive_tasks = 2;

    std::map<std::string, std::tuple<std::tuple<double,double,double>, std::tuple<double,double,double>>> start_goal_configs;

    // Parse start & goal configurations.
    while(getline(infile, line)){
        std::istringstream ss(line);
        std::string buf;
        std::string param[num_param];
        for (int i = 0; i < num_param; i++) {
            getline(ss, buf, ',');
            param[i] = buf;
        }
        auto start_config = std::make_tuple(stod(param[1]), stod(param[2]), stod(param[3]));
        auto goal_config = std::make_tuple(stod(param[4]), stod(param[5]), stod(param[6]));
        auto object_name = param[0];
        start_goal_configs.insert(make_pair(object_name, std::make_tuple(start_config, goal_config)));
    }
    infile.close();

    tasks = this->GetTasks();
    // Generate parsed task planning result.
    for (int i = 0; i < this->task_num; i+= num_primitive_tasks){
        //auto [action, object, config] = tasks[i];
        std::string action, object, config;
        action = std::get<0>(tasks[i]);
        object = std::get<1>(tasks[i]);
        config = std::get<2>(tasks[i]);
        boost::to_lower(object);
        auto target_config = start_goal_configs.find(object);
        if (target_config == start_goal_configs.end()){
            ROS_INFO("error: Target object does not exist.");
        }

        std::tuple<double, double, double> start, goal;
        start = std::get<0>(target_config->second);
        goal = std::get<1>(target_config->second);
        double s_x, s_y, s_z, g_x, g_y, g_z;

        s_x = std::get<0>(start);
        s_y = std::get<1>(start);
        s_z = std::get<2>(start);

        g_x = std::get<0>(goal);
        g_y = std::get<1>(goal);
        g_z = std::get<2>(goal);

        outfile << object << " "  << s_x << " " << s_y << " " << s_z << " " \
                                  << g_x << " " << g_y << " " << g_z << " " << std::endl;
    }

    outfile.close();
}

void TaskPlanner::SetProjectPath(const std::string project_path) {
    this->project_path = project_path;
}
