/* Author: Mincheul Kang */

#ifndef KINEMATICS_SOLVER_H
#define KINEMATICS_SOLVER_H

#include <kdl/chainiksolverpos_nr_jl.hpp>
#include <trac_ik/trac_ik.hpp>
#include <hyundai_planner/Scene.h>
#include <moveit/move_group_interface/move_group_interface.h>


class KinematicsSolver {
public:
    KinematicsSolver(std::string base_link, std::string tip_link, const unsigned int num_dof,
                     planning_scene::PlanningScenePtr& planning_scene,
                     const std::string& PLANNING_GROUP,
                     collision_detection::CollisionRequest &collision_request,
                     robot_state::RobotStatePtr robot_state);
    virtual ~KinematicsSolver(){};

    bool ikSolver(const KDL::JntArray& q_init, const KDL::Frame& p_in, KDL::JntArray& q_out);
    void fkSolver(const KDL::JntArray& q, KDL::Frame& p);
    void computeJacobian(const KDL::JntArray& q, KDL::Jacobian& jac);

    std::vector<double> getGoalConfigs( std::vector<double> q_init,
                                        const double goal_x, const double goal_y, const double goal_z,
                                        const double goal_roll, const double goal_pitch, const double goal_yaw,
                                        const double offset_z);
    bool isValid(const std::vector<double> &values);

private:
    KDL::Chain chain_;
    KDL::JntArray ll_, ul_; //lower joint limits, upper joint limits

    std::unique_ptr<TRAC_IK::TRAC_IK> tracik_solver_;
    std::unique_ptr<KDL::ChainFkSolverPos_recursive> fk_solver_;
    std::unique_ptr<KDL::ChainJntToJacSolver> jacsolver_;

    planning_scene::PlanningScenePtr planning_scene_;
    std::string PLANNING_GROUP_;
    collision_detection::CollisionRequest collision_request_;
    robot_state::RobotStatePtr robot_state_;

    unsigned int num_dof_;
};

typedef std::shared_ptr<KinematicsSolver> KinematicsSolverPtr;

#endif