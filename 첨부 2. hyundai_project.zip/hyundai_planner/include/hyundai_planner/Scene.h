/* Author: Mincheul Kang */

#ifndef SCENE_H
#define SCENE_H

#include <moveit/planning_scene_interface/planning_scene_interface.h>
#include <moveit/planning_scene/planning_scene.h>
#include <ostream>
#include <tf/LinearMath/Quaternion.h>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <string>
#include <ros/ros.h>
#include <ros/package.h>
#include <boost/algorithm/string.hpp>

class Scene {
public:
    Scene(planning_scene::PlanningScenePtr &planning_scene, std::string frameID);

    void addCollisionObjects(const std::string scene_num);

    static std::vector<moveit_msgs::ObjectColor> getColorObjects(const std::vector<moveit_msgs::CollisionObject>& objects);

    static std_msgs::ColorRGBA getRGBA(const std::string& color, double alpha);

    void updateGlobalCollisionScene();

    moveit_msgs::CollisionObject addBox(std::string name,
                                        double x, double y, double z,
                                        double d_x, double d_y, double d_z,
                                        double roll, double pitch, double yaw);

    void removeBox(std::string name);

    std::vector<moveit_msgs::CollisionObject> getBox();

    void removeCollisionObject(const std::string &object_id);

    void updateCollisionObject(const std::string &object_id,
                               double x, double y, double z,
                               double roll, double pitch, double yaw);

    geometry_msgs::Pose getPose();

    shape_msgs::SolidPrimitive getPrimitive(const std::string &object_id);

    moveit::planning_interface::PlanningSceneInterface getPlanningSceneInterface();

    void addAttachedCollisionObject(const std::string& collision_object_id);
    void detachAttachedCollisionObject(const std::string& collision_object_id);
protected:

    moveit::planning_interface::PlanningSceneInterface planning_scene_interface_;
    std::string frameID_;
    planning_scene::PlanningScenePtr planning_scene_;
    std::vector<moveit_msgs::CollisionObject> collision_objects;
};

typedef std::shared_ptr<Scene> ScenePtr;

#endif
