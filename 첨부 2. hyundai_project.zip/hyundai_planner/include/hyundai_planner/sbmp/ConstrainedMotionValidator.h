/* Author: Mincheul Kang */

#ifndef CONSTRAINEDMOTIONVALIDATOR_H_
#define CONSTRAINEDMOTIONVALIDATOR_H_

#include <boost/shared_ptr.hpp>
#include <boost/weak_ptr.hpp>
#include <ompl/base/StateSpace.h>
#include <ompl/base/spaces/SO2StateSpace.h>
#include <ompl/base/spaces/RealVectorStateSpace.h>
#include <ompl/base/MotionValidator.h>

#include <moveit/planning_scene_interface/planning_scene_interface.h>
#include <moveit/planning_scene_monitor/planning_scene_monitor.h>
#include <moveit_msgs/GetPlanningScene.h>
#include <moveit/move_group_interface/move_group_interface.h>

#include <queue>
#include <hyundai_planner/KinematicsSolver.h>

class ConstrainedMotionValidator: public ompl::base::MotionValidator {
public:
    ConstrainedMotionValidator(const ompl::base::SpaceInformationPtr &si,
                               KinematicsSolverPtr &ksolver,
                               const std::vector<bool> &is_continuous,
                               const std::vector<std::pair<double, double> > &constraints,
                               const std::vector<double> &start_state);
    virtual ~ConstrainedMotionValidator(){};

    virtual bool checkMotion(const ompl::base::State *s1, const ompl::base::State *s2) const;
    virtual bool checkMotion(const ompl::base::State *s1, const ompl::base::State *s2, std::pair<ompl::base::State *, double> &lastValid) const;

    std::vector<double> getEEPose(ompl::base::State *state) const;
    void updateConstraints(ompl::base::State *state);
    bool satisfyConstraints(ompl::base::State *state) const;
protected:
    ompl::base::StateSpace * state_space_;
    ompl::base::SpaceInformationPtr si_;

    KinematicsSolverPtr                                    ksolver_;
    std::vector<std::pair<double, double> >                constraints_;
    std::vector<std::pair<double, double> >                update_constraints_;
    std::vector<bool>                                      is_continuous_;
    KDL::Frame                                             baseFrame_;
};

typedef std::shared_ptr<ConstrainedMotionValidator> ConstrainedMotionValidatorPtr;

#endif