/* Author: Mincheul Kang */

#ifndef SAMPLING_BASED_MOTION_PLANNER_H_
#define SAMPLING_BASED_MOTION_PLANNER_H_

#include <boost/shared_ptr.hpp>
#include <boost/weak_ptr.hpp>

#include <ompl/geometric/SimpleSetup.h>
#include <ompl/base/spaces/RealVectorStateSpace.h>
#include <ompl/geometric/planners/prm/ConnectionStrategy.h>
#include <ompl/datastructures/NearestNeighbors.h>
#include <ompl/base/goals/GoalStates.h>
#include <ompl/base/DiscreteMotionValidator.h>

#include <moveit/planning_scene_interface/planning_scene_interface.h>
#include <moveit/planning_scene_monitor/planning_scene_monitor.h>
#include <moveit_msgs/GetPlanningScene.h>
#include <moveit/move_group_interface/move_group_interface.h>
#include <moveit_msgs/DisplayTrajectory.h>

#include <hyundai_planner/sbmp/StateValidityChecker.h>
#include <hyundai_planner/KinematicsSolver.h>
#include <hyundai_planner/sbmp/ConstrainedMotionValidator.h>

class SBMPlanner {
public:
    SBMPlanner(const std::string &planning_group, planning_scene::PlanningScenePtr& planning_scene);
    virtual ~SBMPlanner(){};

    planning_scene::PlanningScenePtr planning_scene_;
    std::string planning_group_;

    bool solve(const std::vector<double> &s_conf, const std::vector<double> &g_conf, const double planning_time,
               double &elapsed_time);
    bool solve(const std::vector<double> &s_conf, const std::vector<double> &g_conf, const double planning_time,
               KinematicsSolverPtr &kinematicsSolver, const std::vector<std::pair<double, double> > &constraints,
               double &elapsed_time);
    void pathVisualization(int N_interpol, float dip_dt);
private:
    unsigned int num_dof_;
    ompl::base::StateSpacePtr state_space_;
    ompl::geometric::SimpleSetupPtr simple_setup_;
    std::vector<bool> is_continuous_;
};

typedef std::shared_ptr<SBMPlanner> SBMPlannerPtr;

#endif