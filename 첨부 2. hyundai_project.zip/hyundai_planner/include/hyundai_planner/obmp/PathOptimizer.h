#ifndef HYUNDAI_PLANNER_PATHOPTIMIZER_H
#define HYUNDAI_PLANNER_PATHOPTIMIZER_H

#include <random>
#include <ros/ros.h>
#include <visualization_msgs/MarkerArray.h>
#include <moveit/robot_model/robot_model.h>
#include <moveit/robot_state/robot_state.h>
#include <moveit/planning_scene/planning_scene.h>
#include <moveit/robot_state/conversions.h>
#include <hyundai_planner/obmp/CostBase.h>
#include <moveit/collision_distance_field/collision_robot_hybrid.h>
#include <moveit/collision_distance_field/collision_world_hybrid.h>
#include <Eigen/Eigen>
#include <hyundai_planner/obmp/Path.h>
#include <hyundai_planner/KinematicsSolver.h>

class PathOptimizer {
public:
    PathOptimizer(std::shared_ptr<Path>& path, const planning_scene::PlanningSceneConstPtr& planningScene,
                  const std::string& group, const moveit::core::RobotState& robotState,
                  KinematicsSolverPtr &ksolver, const std::vector<std::pair<double, double> > &constraints, bool use_constraints);
    void initialize();

    bool optimize(double timeLimit);
    bool solve(const moveit_msgs::MotionPlanRequest& req, double timeLimit,
               moveit_msgs::MotionPlanDetailedResponse& res);

    double calculatePotential(double distance, double radius, double clearence);
    void calculateJacobianAt(int point, Eigen::Vector3d& colliPose, std::string& jointName, Eigen::MatrixXd& jaco);
    void calculateForwardKinematics();
    void fixJointLimitViolation();
    std::vector<double> getEEPose(KDL::Frame &p);
    void updateConstraints(KDL::Frame &p);
    bool satisfyConstraints(KDL::Frame &p);
    void computeConstraintCost();
    double computeConstraint(KDL::Frame &p, Eigen::VectorXd &vec);
    bool isCurrentTrajectorySatisfyConstraint();

    bool isParent(const std::string& child, const std::string& parent){
        if(child == parent)
            return true;
        if(jointParent_.find(child) == jointParent_.end())
            return false;

        auto parents = jointParent_.at(child);
        return parents.find(parent) != parents.end() && parents.at(parent);
    }
    void setCurrentStateAs(int point, Path& groupPath);

    bool isInitialized_ = false;
    bool isCollisionFree_ = false;

    int n_joints_;
    int n_plannablePoints_;
    int n_points_;
    int n_colliPoints_;
    int plannableStart_;
    int plannableEnd_;
    int iteration_;
    size_t colliFreeIteration_;

    std::shared_ptr<Path> path_;
    moveit::core::RobotModelConstPtr robotModel_;
    std::string group_;
    Path groupPath_;
    Eigen::MatrixXd bestGroupPath_;
    double bestCost_ = INFINITY;
    planning_scene::PlanningSceneConstPtr planningScene_;
    moveit::core::RobotState currState_;
    moveit::core::RobotState startState_;

    std::shared_ptr<collision_detection::CollisionWorldHybrid> colliWorld_;
    std::shared_ptr<collision_detection::CollisionRobotHybrid> colliRobot_;
    collision_detection::GroupStateRepresentationPtr groupStateRepresentation_;
    Eigen::MatrixXd collisionIncrement_;
    Eigen::MatrixXd constraintIncrement_;
    std::vector<std::vector<std::string> > colliJointNames_;
    std::vector<EigenSTL::vector_Vector3d> colliPose_;
    std::vector<EigenSTL::vector_Vector3d> colliVel_;
    std::vector<EigenSTL::vector_Vector3d> colliAcc_;
    std::vector<std::vector<double> > colliPotential_;
    std::vector<std::vector<double> > colliSpeed_;
    std::vector<EigenSTL::vector_Vector3d> colliPotentialGradient_;
    std::vector<int> colliStates_;
    std::vector<std::vector<int> > colliPoints_;
    int n_colliFreeIter_;

    std::vector<CostBase> jointSmoothCost_;
    const moveit::core::JointModelGroup* jointModelGroup_;
    Eigen::MatrixXd smoothIncrement_;

    Eigen::MatrixXd costIncrement_;
    Eigen::VectorXd dSmoothness_;
    Eigen::MatrixXd jacobian_;
    Eigen::MatrixXd jacobianInv_;
    Eigen::MatrixXd jacoJacoTrans_;

    std::vector<std::string> jointNames_;
    std::vector<EigenSTL::vector_Vector3d> jointAxes_;
    std::vector<EigenSTL::vector_Vector3d> jointPositions_;
    std::map<std::string, std::map<std::string, bool> > jointParent_;

    bool use_constraints_;
    KinematicsSolverPtr ksolver_;
    std::vector<std::pair<double, double> > constraints_;
    std::vector<std::pair<double, double> > update_constraints_;
    double constraints_value_;
    std::vector<double> referPose_;
    bool constraints_state_;
};


#endif //HYUNDAI_PLANNER_PATHOPTIMIZER_H
