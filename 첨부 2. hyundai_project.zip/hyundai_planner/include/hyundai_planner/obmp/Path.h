#ifndef HYUNDAI_PLANNER_PATH_H
#define HYUNDAI_PLANNER_PATH_H

#include <trajectory_msgs/JointTrajectory.h>
#include <moveit/robot_model/robot_model.h>
#include <moveit_msgs/MotionPlanDetailedResponse.h>
#include <moveit_msgs/MotionPlanRequest.h>
#include <hyundai_planner/obmp/Utils.h>

#include <Eigen/Eigen>

class Path {
public:
    Path(const moveit::core::RobotModelConstPtr& model, double duration, double discretization, const std::string& group);
    Path(const Path& original_path, const std::string& group);

    double& at(int point, int joint){
        return path_(point, joint);
    }
    double at(int point, int joint) const {
        return path_(point, joint);
    }
    void update(const Path& path);
    Eigen::MatrixXd::RowXpr getPointAt(int point){
        return path_.row(point);
    }
    Eigen::MatrixXd::ColXpr getJointsAt(int joint){
        return path_.col(joint);
    }
    int getNumPlannablePoints() const {
        return (endIdx_ - startIdx_) + 1;
    }
    Eigen::Block<Eigen::MatrixXd, Eigen::Dynamic, Eigen::Dynamic> getPlannablePath(){
        return path_.block(startIdx_, 0, getNumPlannablePoints(), n_joints);
    }
    Eigen::Block<Eigen::MatrixXd, Eigen::Dynamic, Eigen::Dynamic> getPlannableJointAt(int joint){
        return path_.block(startIdx_, joint, getNumPlannablePoints(), 1);
    }

    void setPathWithMinimumJerk();

    int n_points;
    int n_joints;
    double discretization_;
    double duration_;
    int startIdx_;
    int endIdx_;

    Eigen::MatrixXd path_;
};


#endif //HYUNDAI_PLANNER_PATH_H
