/* Author: Mincheul Kang */

#ifndef OPTIMIZATION_BASED_MOTION_PLANNER_H
#define OPTIMIZATION_BASED_MOTION_PLANNER_H

#include <boost/shared_ptr.hpp>
#include <boost/weak_ptr.hpp>

#include <moveit/planning_scene_interface/planning_scene_interface.h>
#include <moveit/planning_scene_monitor/planning_scene_monitor.h>
#include <moveit_msgs/GetPlanningScene.h>
#include <moveit/move_group_interface/move_group_interface.h>
#include <moveit_msgs/DisplayTrajectory.h>
#include <moveit/robot_model_loader/robot_model_loader.h>
#include <moveit/planning_interface/planning_interface.h>
#include <moveit/kinematic_constraints/utils.h>
#include <moveit_msgs/DisplayTrajectory.h>
#include <moveit_msgs/AttachedCollisionObject.h>
#include <moveit/planning_scene_interface/planning_scene_interface.h>

#include <hyundai_planner/Scene.h>
#include <hyundai_planner/KinematicsSolver.h>

class OBMPlanner {
public:
    OBMPlanner(const std::string &planning_group, planning_scene::PlanningScenePtr& planning_scene, ScenePtr& scene);
    virtual ~OBMPlanner(){};

    planning_scene::PlanningScenePtr planning_scene_;
    std::string planning_group_;
    ScenePtr scene_;

    bool solve(const std::vector<double> &s_conf, const std::vector<double> &g_conf, const double planning_time,
               const std::string& collision_object_id, double &elapsed_time,
               KinematicsSolverPtr &ksolver, const std::vector<std::pair<double, double> > &constraints, bool use_constraints);
    void pathVisualization(float dip_dt);
private:
    unsigned int num_dof_;
    bool planning_success_;
    const robot_state::JointModelGroup* joint_model_group_;
    robot_model::RobotModelPtr robot_model_;
    sensor_msgs::JointState joint_state_;

    moveit_msgs::MotionPlanRequest mpr_;
    moveit_msgs::MotionPlanDetailedResponse mpdr_;
};

typedef std::shared_ptr<OBMPlanner> OBMPlannerPtr;

#endif
