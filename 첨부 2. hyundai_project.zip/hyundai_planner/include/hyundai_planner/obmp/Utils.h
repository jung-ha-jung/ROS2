#ifndef HYUNDAI_PLANNER_UTILS_H
#define HYUNDAI_PLANNER_UTILS_H

#define SMALL 0.0001

#define DIFF_LEN 7
const double DIFF_COEFF[3][DIFF_LEN] = {
        { 0, 0, -2 / 6.0, -3 / 6.0, 6 / 6.0, -1 / 6.0, 0 },
        { 0, -1 / 12.0, 16 / 12.0, -30 / 12.0, 16 / 12.0, -1 / 12.0, 0 },
        { 0, 1 / 12.0, -17 / 12.0, 46 / 12.0, -46 / 12.0, 17 / 12.0, -1 / 12.0 }
};

#define SMOOTH_VEL 0.
#define SMOOTH_ACC 0.2
#define SMOOTH_JERK 0.
#define RIDGE 0.

#define MAX_ITER 500
#define MIN_CLEARENCE 0.3

#define WEIGHT_COLLISION_COST 1.0
#define WEIGHT_SMOOTH_COST 0.001

#define LEARNING_RATE 0.2
#define JOINT_UPDATE_LIMIT 0.1

#define MESH_TO_MESH_COLLISION_CHECK_TERM 10

static inline double normalizeAnglePositive(double angle)
{
    return fmod(fmod(angle, 2.0 * M_PI) + 2.0 * M_PI, 2.0 * M_PI);
}

static inline double normalizeAngle(double angle)
{
    double a = normalizeAnglePositive(angle);
    if (a > M_PI)
        a -= 2.0 * M_PI;
    return a;
}

static inline double shortestAngularDistance(double start, double end)
{
    double res = normalizeAnglePositive(normalizeAnglePositive(end) - normalizeAnglePositive(start));
    if (res > M_PI)
    {
        res = -(2.0 * M_PI - res);
    }
    return normalizeAngle(res);
}

#endif //HYUNDAI_PLANNER_UTILS_H
