#ifndef HYUNDAI_PLANNER_COSTBASE_H
#define HYUNDAI_PLANNER_COSTBASE_H

#include <hyundai_planner/obmp/Path.h>

class CostBase {
public:
    CostBase(const Path& path, const std::vector<double>& dCost, double ridge = 0);

    Eigen::MatrixXd calculateDiff(int size, int diffIdx);
    void scale(double scale){
        if(scale == 0){
            ROS_ERROR("Scale with 0");
            return;
        }

        double invScale = 1./scale;
        quadraticCostInv_ *= invScale;
        quadraticCost_ *= scale;
        quadraticFullCost_ *= scale;
    }
    double getCost(Eigen::MatrixXd::ColXpr joint){
        return joint.dot(quadraticFullCost_ * joint);
    }

    Eigen::MatrixXd quadraticFullCost_;
    Eigen::MatrixXd quadraticCost_;
    Eigen::MatrixXd quadraticCostInv_;
};


#endif //HYUNDAI_PLANNER_COSTBASE_H
