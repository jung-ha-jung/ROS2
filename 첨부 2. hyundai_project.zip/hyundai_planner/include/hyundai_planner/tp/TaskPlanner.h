/* Author: Hyeongyeol Ryu */

#ifndef TASK_PLANNER_H
#define TASK_PLANNER_H

#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <tuple>
#include <map>
#include <ros/ros.h>
#include <ros/package.h>
#include <boost/algorithm/string.hpp>

#define NUM_OF_BOXES 18

class TaskPlanner {
public:
    TaskPlanner(const std::string soln_file_path);
    ~TaskPlanner()= default;
    void ParseTask();
    void ParseStartGoalConfig();
    void GenerateParsedFile();
    void SetProjectPath(const std::string project_path);
    std::vector<std::tuple<std::string, std::string, std::string>> GetTasks();
    std::vector<std::tuple<std::string, std::tuple<double,double,double>, std::tuple<double,double,double>>> GetConfigs();
private:
    std::string soln_file_path;
    std::vector<std::tuple<std::string, std::string, std::string>> tasks;
    unsigned task_num;
    std::vector<std::tuple<std::string, std::tuple<double,double,double>, std::tuple<double,double,double>>> configs;
    std::string project_path;
};

#endif
