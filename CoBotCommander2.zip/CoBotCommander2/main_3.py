# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'c:\form.ui'
#
# Created by: PyQt5 UI code generator 5.13.1
#
# WARNING! All changes made in this file will be lost!

# PyQT designer -> code 변환 방법
# pyuic5 -x c:\form.ui -o c:\form.py

import requests
import json
import time
import sys
import transcribe_streaming_mic
from datetime import datetime
from PyQt5 import QtCore, QtGui, QtWidgets
# import speech_recognition
# import pyaudio
# import os
from threading import Thread

headers = {'Content-Type': 'application/json; charset=utf-8', }
program_select_address = 'http://localhost:8888/project/svc_job/SET_CUR_PROG_CNT'
program_start_address = 'http://localhost:8888/project/robot/start'
program_stop_address = 'http://localhost:8888/project/robot/stop'
program_record_address = 'http://localhost:8888/project/jobs/0001.JOB/INS_CMD_LINE'
direct_teach_address = 'http://localhost:8888/project/svc_status/SET_DIRECT_TEACH_MODE'
motor_on_address = 'http://localhost:8888/project/robot/motor_on'
motor_off_address = 'http://localhost:8888/project/robot/motor_off'
manual_mode_address = 'http://localhost:8888/project/robot/manual_mode'
auto_mode_address = 'http://localhost:8888/project/robot/auto_mode'
lob_lang_var_change = 'http://localhost:8888/project/tasks[0]/assign_var_expr'
get_robot_mode = 'http://localhost:8888/project/svc_status/rgen'


class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName("Dialog")
        Dialog.resize(1368, 912)
        Dialog.setStyleSheet("QDialog {background-image:url(background.png);}\n"
                             "")
        self.splitter = QtWidgets.QSplitter(Dialog)
        self.splitter.setGeometry(QtCore.QRect(0, 0, 0, 0))
        self.splitter.setOrientation(QtCore.Qt.Vertical)
        self.splitter.setObjectName("splitter")
        self.groupBox = QtWidgets.QGroupBox(Dialog)
        self.groupBox.setGeometry(QtCore.QRect(20, 60, 650, 661))
        self.groupBox.setTitle("")
        self.groupBox.setObjectName("groupBox")
        self.gridLayout = QtWidgets.QGridLayout(self.groupBox)
        self.gridLayout.setObjectName("gridLayout")
        self.verticalLayout = QtWidgets.QVBoxLayout()
        self.verticalLayout.setObjectName("verticalLayout")
        self.pushButton_motor_on = QtWidgets.QPushButton(self.groupBox)
        self.pushButton_motor_on.setEnabled(True)
        self.pushButton_motor_on.setMinimumSize(QtCore.QSize(190, 150))
        font = QtGui.QFont()
        font.setFamily("Calibri")
        font.setPointSize(20)
        self.pushButton_motor_on.setFont(font)
        self.pushButton_motor_on.setStyleSheet("")
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap("motor_on.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.pushButton_motor_on.setIcon(icon)
        self.pushButton_motor_on.setIconSize(QtCore.QSize(48, 48))
        self.pushButton_motor_on.setFlat(False)
        self.pushButton_motor_on.setObjectName("pushButton_motor_on")
        self.verticalLayout.addWidget(self.pushButton_motor_on)
        self.pushButton_motor_off = QtWidgets.QPushButton(self.groupBox)
        self.pushButton_motor_off.setMinimumSize(QtCore.QSize(190, 150))
        font = QtGui.QFont()
        font.setFamily("Calibri")
        font.setPointSize(20)
        self.pushButton_motor_off.setFont(font)
        icon1 = QtGui.QIcon()
        icon1.addPixmap(QtGui.QPixmap("motor_off.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.pushButton_motor_off.setIcon(icon1)
        self.pushButton_motor_off.setIconSize(QtCore.QSize(48, 48))
        self.pushButton_motor_off.setFlat(False)
        self.pushButton_motor_off.setObjectName("pushButton_motor_off")
        self.verticalLayout.addWidget(self.pushButton_motor_off)
        self.gridLayout.addLayout(self.verticalLayout, 0, 0, 3, 1)
        self.verticalLayout_2 = QtWidgets.QVBoxLayout()
        self.verticalLayout_2.setObjectName("verticalLayout_2")
        self.dial = QtWidgets.QDial(self.groupBox)
        self.dial.setMinimumSize(QtCore.QSize(110, 110))
        self.dial.setStyleSheet("background-color : rgb(64,64,64);")
        self.dial.setMaximum(1)
        self.dial.setPageStep(10)
        self.dial.setProperty("value", 1)
        self.dial.setSliderPosition(1)
        self.dial.setOrientation(QtCore.Qt.Horizontal)
        self.dial.setWrapping(False)
        self.dial.setNotchTarget(44.7)
        self.dial.setNotchesVisible(True)
        self.dial.setObjectName("dial")
        self.verticalLayout_2.addWidget(self.dial)
        self.gridLayout.addLayout(self.verticalLayout_2, 0, 1, 3, 1)
        self.horizontalLayout_2 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_2.setSizeConstraint(QtWidgets.QLayout.SetMinAndMaxSize)
        self.horizontalLayout_2.setSpacing(12)
        self.horizontalLayout_2.setObjectName("horizontalLayout_2")
        self.label = QtWidgets.QLabel(self.groupBox)
        font = QtGui.QFont()
        font.setFamily("Aharoni")
        font.setPointSize(20)
        font.setBold(True)
        font.setWeight(75)
        self.label.setFont(font)
        self.label.setLayoutDirection(QtCore.Qt.LeftToRight)
        self.label.setAlignment(QtCore.Qt.AlignCenter)
        self.label.setObjectName("label")
        self.horizontalLayout_2.addWidget(self.label)
        self.textEdit = QtWidgets.QTextEdit(self.groupBox)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.textEdit.sizePolicy().hasHeightForWidth())
        self.textEdit.setSizePolicy(sizePolicy)
        self.textEdit.setMinimumSize(QtCore.QSize(550, 0))
        self.textEdit.setMaximumSize(QtCore.QSize(310, 80))
        self.textEdit.setStyleSheet("background-color : rgb(217,237,226);")
        self.textEdit.setObjectName("textEdit")
        self.horizontalLayout_2.addWidget(self.textEdit)
        self.gridLayout.addLayout(self.horizontalLayout_2, 3, 0, 1, 2)
        self.gridLayout.setRowStretch(0, 1)
        self.label_2 = QtWidgets.QLabel(Dialog)
        self.label_2.setGeometry(QtCore.QRect(1100, 20, 251, 21))
        self.label_2.setText("")
        self.label_2.setPixmap(QtGui.QPixmap("CI.png"))
        self.label_2.setObjectName("label_2")
        self.groupBox_2 = QtWidgets.QGroupBox(Dialog)
        self.groupBox_2.setGeometry(QtCore.QRect(700, 60, 650, 661))
        self.groupBox_2.setTitle("")
        self.groupBox_2.setObjectName("groupBox_2")
        self.gridLayout_3 = QtWidgets.QGridLayout(self.groupBox_2)
        self.gridLayout_3.setObjectName("gridLayout_3")
        self.gridLayout_2 = QtWidgets.QGridLayout()
        self.gridLayout_2.setObjectName("gridLayout_2")
        self.pushButton_1 = QtWidgets.QPushButton(self.groupBox_2)
        self.pushButton_1.setMinimumSize(QtCore.QSize(170, 150))
        font = QtGui.QFont()
        font.setFamily("Calibri")
        font.setPointSize(20)
        self.pushButton_1.setFont(font)
        self.pushButton_1.setStyleSheet("QPushButton {background-color : rgb(167,216,186);}\n"
                                        "\n"
                                        "QPushButton:pressed {background-color : rgb(65,183,139); color : white;}")
        self.pushButton_1.setFlat(False)
        self.pushButton_1.setObjectName("pushButton_1")
        self.gridLayout_2.addWidget(self.pushButton_1, 0, 0, 1, 1)
        self.pushButton_2 = QtWidgets.QPushButton(self.groupBox_2)
        self.pushButton_2.setMinimumSize(QtCore.QSize(170, 150))
        font = QtGui.QFont()
        font.setFamily("Calibri")
        font.setPointSize(20)
        self.pushButton_2.setFont(font)
        self.pushButton_2.setStyleSheet("QPushButton {background-color : rgb(167,216,186);}\n"
                                        "QPushButton:pressed {background-color : rgb(65,183,139); color : white;}")
        self.pushButton_2.setObjectName("pushButton_2")
        self.gridLayout_2.addWidget(self.pushButton_2, 3, 0, 1, 1)
        self.pushButton_3 = QtWidgets.QPushButton(self.groupBox_2)
        self.pushButton_3.setMinimumSize(QtCore.QSize(170, 150))
        font = QtGui.QFont()
        font.setFamily("Calibri")
        font.setPointSize(20)
        self.pushButton_3.setFont(font)
        self.pushButton_3.setStyleSheet("QPushButton {background-color : rgb(167,216,186);}\n"
                                        "QPushButton:pressed {background-color : rgb(65,183,139); color : white;}")
        self.pushButton_3.setObjectName("pushButton_3")
        self.gridLayout_2.addWidget(self.pushButton_3, 4, 0, 1, 1)
        self.pushButton_8 = QtWidgets.QPushButton(self.groupBox_2)
        self.pushButton_8.setMinimumSize(QtCore.QSize(170, 150))
        font = QtGui.QFont()
        font.setFamily("Calibri")
        font.setPointSize(20)
        self.pushButton_8.setFont(font)
        self.pushButton_8.setStyleSheet("QPushButton {background-color : rgb(167,216,186);}\n"
                                        "\n"
                                        "QPushButton:pressed {background-color : rgb(65,183,139); color : white;}")
        self.pushButton_8.setObjectName("pushButton_8")
        self.gridLayout_2.addWidget(self.pushButton_8, 6, 1, 1, 1)
        self.pushButton_4 = QtWidgets.QPushButton(self.groupBox_2)
        self.pushButton_4.setMinimumSize(QtCore.QSize(170, 150))
        font = QtGui.QFont()
        font.setFamily("Calibri")
        font.setPointSize(20)
        self.pushButton_4.setFont(font)
        self.pushButton_4.setStyleSheet("QPushButton {background-color : rgb(167,216,186);}\n"
                                        "\n"
                                        "QPushButton:pressed {background-color : rgb(65,183,139); color : white;}")
        self.pushButton_4.setObjectName("pushButton_4")
        self.gridLayout_2.addWidget(self.pushButton_4, 6, 0, 1, 1)
        self.pushButton_7 = QtWidgets.QPushButton(self.groupBox_2)
        self.pushButton_7.setMinimumSize(QtCore.QSize(170, 150))
        font = QtGui.QFont()
        font.setFamily("Calibri")
        font.setPointSize(20)
        self.pushButton_7.setFont(font)
        self.pushButton_7.setStyleSheet("QPushButton {background-color : rgb(167,216,186);}\n"
                                        "\n"
                                        "QPushButton:pressed {background-color : rgb(65,183,139); color : white;}")
        self.pushButton_7.setObjectName("pushButton_7")
        self.gridLayout_2.addWidget(self.pushButton_7, 4, 1, 1, 1)
        self.pushButton_6 = QtWidgets.QPushButton(self.groupBox_2)
        self.pushButton_6.setMinimumSize(QtCore.QSize(170, 150))
        font = QtGui.QFont()
        font.setFamily("Calibri")
        font.setPointSize(20)
        self.pushButton_6.setFont(font)
        self.pushButton_6.setStyleSheet("QPushButton {background-color : rgb(167,216,186);}\n"
                                        "\n"
                                        "QPushButton:pressed {background-color : rgb(65,183,139); color : white;}")
        self.pushButton_6.setObjectName("pushButton_6")
        self.gridLayout_2.addWidget(self.pushButton_6, 3, 1, 1, 1)
        self.pushButton_5 = QtWidgets.QPushButton(self.groupBox_2)
        self.pushButton_5.setMinimumSize(QtCore.QSize(170, 150))
        font = QtGui.QFont()
        font.setFamily("Calibri")
        font.setPointSize(20)
        self.pushButton_5.setFont(font)
        self.pushButton_5.setStyleSheet("QPushButton {background-color : rgb(167,216,186);}\n"
                                        "\n"
                                        "QPushButton:pressed {background-color : rgb(65,183,139); color : white;}")
        self.pushButton_5.setObjectName("pushButton_5")
        self.gridLayout_2.addWidget(self.pushButton_5, 0, 1, 1, 1)
        self.gridLayout_3.addLayout(self.gridLayout_2, 0, 0, 1, 1)
        self.layoutWidget = QtWidgets.QWidget(Dialog)
        self.layoutWidget.setGeometry(QtCore.QRect(20, 750, 1331, 152))
        self.layoutWidget.setObjectName("layoutWidget")
        self.horizontalLayout = QtWidgets.QHBoxLayout(self.layoutWidget)
        self.horizontalLayout.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout.setSpacing(15)
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.pushButton_start = QtWidgets.QPushButton(self.layoutWidget)
        self.pushButton_start.setMinimumSize(QtCore.QSize(320, 150))
        font = QtGui.QFont()
        font.setFamily("Calibri")
        font.setPointSize(20)
        self.pushButton_start.setFont(font)
        self.pushButton_start.setStyleSheet("QPushButton {background-color : rgb(0,0,255); color : white; }\n"
                                            "\n"
                                            "QPushButton:pressed {background-color : rgb(0,0,255,180);}\n"
                                            "")
        self.pushButton_start.setObjectName("pushButton_start")
        self.horizontalLayout.addWidget(self.pushButton_start)
        self.pushButton_stop = QtWidgets.QPushButton(self.layoutWidget)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.pushButton_stop.sizePolicy().hasHeightForWidth())
        self.pushButton_stop.setSizePolicy(sizePolicy)
        self.pushButton_stop.setMinimumSize(QtCore.QSize(320, 150))
        font = QtGui.QFont()
        font.setFamily("Calibri")
        font.setPointSize(20)
        self.pushButton_stop.setFont(font)
        self.pushButton_stop.setStyleSheet("QPushButton {background-color : rgb(255,0,0); color : white; }\n"
                                           "\n"
                                           "QPushButton:pressed {background-color : rgb(255,0,0,180);}")
        self.pushButton_stop.setDefault(False)
        self.pushButton_stop.setFlat(False)
        self.pushButton_stop.setObjectName("pushButton_stop")
        self.horizontalLayout.addWidget(self.pushButton_stop)
        self.label_3 = QtWidgets.QLabel(Dialog)
        self.label_3.setGeometry(QtCore.QRect(560, 480, 61, 31))
        font = QtGui.QFont()
        font.setFamily("Calibri")
        font.setPointSize(20)
        self.label_3.setFont(font)
        self.label_3.setObjectName("label_3")
        self.label_4 = QtWidgets.QLabel(Dialog)
        self.label_4.setGeometry(QtCore.QRect(380, 480, 91, 31))
        font = QtGui.QFont()
        font.setFamily("Calibri")
        font.setPointSize(20)
        self.label_4.setFont(font)
        self.label_4.setObjectName("label_4")
        self.layoutWidget.raise_()
        self.groupBox.raise_()
        self.splitter.raise_()
        self.label_2.raise_()
        self.groupBox_2.raise_()
        self.dial.raise_()
        self.label_3.raise_()
        self.label_4.raise_()

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

        # self.dial.setValue(0) # This is Qdial value Set.
        self.dial.valueChanged.connect(self.dialer_changed)
        self.pushButton_1.clicked.connect(self.direct_teach_on)
        self.pushButton_2.clicked.connect(self.program_sel_2)
        self.pushButton_3.clicked.connect(self.program_sel_3)
        self.pushButton_4.clicked.connect(self.program_sel_4)
        self.pushButton_5.clicked.connect(self.program_sel_5)
        self.pushButton_6.clicked.connect(self.program_sel_6)
        self.pushButton_7.clicked.connect(self.program_sel_7)
        self.pushButton_8.clicked.connect(self.program_sel_8)
        self.pushButton_start.clicked.connect(self.program_start)
        self.pushButton_stop.clicked.connect(self.program_stop)
        self.pushButton_motor_on.clicked.connect(self.motor_on)
        self.pushButton_motor_off.clicked.connect(self.motor_off)
        t1 = Thread(target=self.get_robot_state, args=())
        t1.daemon = True
        #t1.start()

    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "CoBot Commander"))
        self.pushButton_motor_on.setText(_translate("Dialog", "Motor On"))
        self.pushButton_motor_off.setText(_translate("Dialog", "Motor Off"))
        # self.label.setText(_translate("Dialog", "OK"))
        self.pushButton_1.setText(_translate("Dialog", "직접교시 시작"))
        self.pushButton_2.setText(_translate("Dialog", "현재위치 기록"))
        self.pushButton_3.setText(_translate("Dialog", "기록 종료"))
        self.pushButton_4.setText(_translate("Dialog", "직접교시 종료"))
        self.pushButton_5.setText(_translate("Dialog", "교시작업 선택"))
        self.pushButton_6.setText(_translate("Dialog", "1번작업 선택"))
        self.pushButton_7.setText(_translate("Dialog", "2번작업 선택"))
        self.pushButton_8.setText(_translate("Dialog", "3번작업 선택"))
        self.pushButton_start.setText(_translate("Dialog", "Start"))
        self.pushButton_stop.setText(_translate("Dialog", "Stop"))
        self.label_3.setText(_translate("Dialog", "Auto"))
        self.label_4.setText(_translate("Dialog", "Manual"))

    def get_robot_state(self):
        while True:
            response = self.web_service_request('GET', get_robot_mode, "", "")
            if response['cur_mode'] is 3 and self.dial.value() is 0:
                print("Manual")
                self.dial.setValue(1)
            elif response['cur_mode'] is 0 and self.dial.value() is 1:
                print("Auto")
                self.dial.setValue(0)
            time.sleep(0.1)


    def web_request(self, method_name, url, dict_data, is_urlencoded=True, timeout_seconds=3):
        """Web GET or POST request를 호출 후 그 결과를 dict형으로 반환 """
        method_name = method_name.upper()  # 메소드이름을 대문자로 바꾼다
        if method_name not in ('GET', 'POST'):
            raise Exception('method_name is GET or POST plz...')

        if method_name == 'GET':  # GET방식인 경우
            response = requests.get(url=url, params=dict_data, timeout=timeout_seconds)
        elif method_name == 'POST':  # POST방식인 경우
            if is_urlencoded is True:
                response = requests.post(url=url, data=dict_data, \
                                         timeout=timeout_seconds,
                                         headers=headers)
            else:
                response = requests.post(url=url, data=json.dumps(dict_data), \
                                         timeout=timeout_seconds, headers=headers)

        dict_meta = {'status_code': response.status_code, 'ok': response.ok}
        if 'json' in str(response.headers['Content-Type']):  # JSON 형태인 경우
            return {**dict_meta, **response.json()}
        else:  # 문자열 형태인 경우
            return {**dict_meta, **{'text': response.text}}

    def web_request_retry(self, num_retry=3, sleep_seconds=1, **kwargs):
        """timeout발생 시 sleep_seconds쉬고 num_retyrp번 재시도 한다"""
        for n in range(num_retry):
            try:
                return self.web_request(**kwargs)
            except requests.exceptions.Timeout:
                print(str(n + 1) + ' Timeout')
                time.sleep(sleep_seconds)
                continue
        return None

    def web_service_request(self, method, url, data, command):
        try:
            response = self.web_request_retry(method_name=method, url=url, dict_data=data, is_urlencoded=True,
                                              num_retry=3)
            # GET DATA는 상태창에 표시 하지 않는다.
            if method is "GET":
                return response

            if response['ok']:
                self.label.setText("OK")
            else:
                self.label.setText("NG")
            self.stats_log(response, command)

        except Exception as ex:
            print('No response')
            self.stats_log('No response', command)
            self.label.setText("NG")
            return

    def stats_log(self, response, command):
        now = datetime.now()
        log_time = ('%s:%s:%s - ' % (now.hour, now.minute, now.second))
        self.textEdit.append(str(log_time) + str(command) + " : " + str(response))

    def program_sel_1(self):
        data = '{\"pno":1}'
        self.web_service_request('POST', program_select_address, data, "Select 1-Program")

    def program_sel_2(self):
        data = '{\"pno":2}'
        self.web_service_request('POST', program_select_address, data, "Select 2-Program")

    def program_sel_3(self):
        data = '{\"pno":3}'
        self.web_service_request('POST', program_select_address, data, "Select 3-Program")

    def program_sel_4(self):
        data = '{\"pno":4}'
        self.web_service_request('POST', program_select_address, data, "Select 4-Program")

    def program_sel_5(self):
        data = '{\"pno":5}'
        self.web_service_request('POST', program_select_address, data, "Select 5-Program")

    def program_sel_6(self):
        data = '{\"pno":6}'
        self.web_service_request('POST', program_select_address, data, "Select 6-Program")

    def program_sel_7(self):
        data = '{\"pno":7}'
        self.web_service_request('POST', program_select_address, data, "Select 7-Program")

    def program_sel_8(self):
        data = '{\"pno":8}'
        self.web_service_request('POST', program_select_address, data, "Select 8-Program")

    def program_start(self):
        self.web_service_request('POST', program_start_address, '', "Start")

    def program_stop(self):
        self.web_service_request('POST', program_stop_address, '', "Stop")

    def direct_teach_on(self):
        self.dial.setValue(0)
        time.sleep(1)
        self.motor_off()
        time.sleep(2)
        data = '{\"DirectTeachStatus":1}'
        self.web_service_request('POST', direct_teach_address, data, "Direct Teaching On")
        time.sleep(1)
        self.motor_on()

    def direct_teach_off(self):
        data = '{\"DirectTeachStatus":0}'
        self.web_service_request('POST', direct_teach_address, data, "Direct Teaching Off")

    def record(self):
        rec_cnt = '{}'.format(ui.record_count)
        data = '{\"sno_ref":' + rec_cnt + ',"cmd_line":"move P,spd=60%,accu=1,tool=0","set_cur_pose":1}'
        self.web_service_request('POST', program_record_address, data, "record")
        ui.record_count += 1

    def record_end(self):
        data = '{\"cmd_line" : "end","sno_ref" :' + '{}'.format(ui.record_count) + '}'
        self.web_service_request('POST', program_record_address, data, "Record End")
        # ex.record_count += 1

    def motor_on(self):
        self.web_service_request('POST', motor_on_address, '', "Motor On")

    def motor_off(self):
        self.web_service_request('POST', motor_off_address, '', "Motor Off")

    def manual_mode(self):
        self.web_service_request('POST', manual_mode_address, '', "Manual Mode")

    def auto_mode(self):
        self.web_service_request('POST', auto_mode_address, '', "Auto Mode")

    def var_change(self):
        data = '{\"name" : "change_job","expr":1}'
        self.web_service_request('POST', lob_lang_var_change, data, "Robot Var Change")

    def dialer_changed(self):
        dial_value = self.dial.value()
        if dial_value is 0:  # This is Manual Mode
            self.web_service_request('POST', manual_mode_address, '', "Manual Mode")
            print("Manual Mode Change")
        else:
            self.web_service_request('POST', auto_mode_address, '', "Auto Mode")
            print("Auto Mode Change")


if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    Dialog = QtWidgets.QDialog()
    ui = Ui_Dialog()
    ui.setupUi(Dialog)
    Dialog.show()
    # transcribe_streaming_mic.main()
    sys.exit(app.exec_())
